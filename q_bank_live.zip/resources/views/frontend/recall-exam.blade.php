{{-- @extends('frontend.master-frontend')




@section('content') --}}
{{--  data fetch from Database !!  --}}
{{-- OLD CODE <br><br>

<div class="container-fluid">
    <h2 style="font-size: 35px">Recall Exam</h2>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis dolorem similique, illum ut expedita, error assumenda delectus nihil veritatis cupiditate commodi? Illo fugit odio molestiae officia dicta, nostrum modi reprehenderit sapiente aliquid facilis nemo incidunt autem dignissimos dolore quasi. Velit laborum officia quo distinctio magni aperiam incidunt voluptatem corporis, culpa corrupti. Eius ullam ratione aspernatur. Minima a officia nostrum numquam reiciendis mollitia unde perferendis ducimus. Cum consequuntur hic esse quas odit? Reprehenderit aspernatur velit ipsa modi, vitae officia error! Delectus beatae autem inventore minus provident, sed reprehenderit consequatur unde nemo quis natus dolor aspernatur tempora mollitia rerum velit minima corrupti accusantium asperiores non vel. Quis illo repudiandae quidem doloremque, rerum quo dolorum, sit id error obcaecati delectus, voluptate perferendis ab. Ratione quaerat beatae ut, debitis nostrum dicta sint delectus natus quasi illum voluptas maxime corrupti modi facere eaque quisquam sit temporibus culpa earum quam nulla. Deleniti sunt beatae vitae mollitia quidem, cumque eum fuga quam qui repellendus illo sequi dolores placeat eligendi in laboriosam officia explicabo rem nobis temporibus quibusdam. Expedita aliquam porro, asperiores iure nobis obcaecati, inventore, nulla cumque ipsum excepturi voluptates odit rem nisi accusamus illum. Itaque, mollitia! Nam modi, quidem at nihil beatae eaque minima perspiciatis reprehenderit.
    </p>
    @foreach ($expired_data as $key => $item)
        <a href="{{ url('q-bank/recall-exam/result/'.$item->id) }}" class="btn btn-danger extraCustomCSS_btn mr-1">{{ $item->mockinfo_recall->name }}<a>
    @endforeach
    @if($exists_data != '0')
        @foreach ($continue_data as $item)
            <a href="{{ url('q-bank/recall-exam/'.$item->id) }}" class="btn extraCustomCSS_btn btn-success">Continue Exam</a>
        @endforeach
    @else
        @foreach ($available_exam as $item)
            @if ( $item->status == '1' && !in_array($item->id,$array))
                <a href="{{ url('q-bank/exam/recall-exam') }}" class="btn extraCustomCSS_btn btn-info mr-1">{{ $item->name }}<a>
            @endif
        @endforeach
    @endif
</div>
<br><br> --}}
{{-- @endsection --}}

@extends('frontend.master-frontend')
@section('content')
<br>
{{--  data fetch from Database !!  --}}

    <div class="container-fluid" style="padding-left: 25px; padding-right: 25px">
        <div class='page_banner_img_common'>
            <img src='/frontend/images/pages-banner.png' class='img-fluid'>
            <div class='overlay__'>
                <p>Recall Exam</p>
            </div>
        </div>
    
        <div class="col-lg-12 col-md-12 col-sm-12 text-center">
            <h2 style="font-size: 35px;">Recall Exam</h2>
            <br>
            <p class="text-justify">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </p>
        </div>
        <br><br>
        
        <div class="row">
            {{-- OLD CODE
            @foreach ($data as $key=>$item)
                <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                    
                    @if ($key%4 == '0')
                        <a href="{{ url('q-bank/recall-exam/'.$item->id) }}" class="btn btn-spinner extraCustomCSS_btn col-12" style="background:darkviolet">{{ $item->name }}</a>
                    @elseif($key%3 == '0')
                        <a href="{{ url('q-bank/recall-exam/'.$item->id) }}" class="btn btn-spinner extraCustomCSS_btn col-12" style="background:violet">{{ $item->name }}</a>
                    @elseif($key%2 == '0')
                        <a href="{{ url('q-bank/recall-exam/'.$item->id) }}" class="btn btn-spinner extraCustomCSS_btn col-12" style="background:darkblue">{{ $item->name }}</a>
                    @else
                        <a href="{{ url('q-bank/recall-exam/'.$item->id) }}" class="btn btn-spinner extraCustomCSS_btn col-12" style="background:hotpink">{{ $item->name }}</a>
                    @endif
                </div>
            @endforeach
            --}}

            @foreach ($data as $item)
                <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                    <a href="{{ url('q-bank/recall-exam/'.$item->id) }}" class="btn btn-spinner col-12 p-0" style="background:{{ $item->cat_color }};padding:0;border-radius:10px;overflow:hidden">
                        <img src="{{ url('storage/photos/'.$item->cat_img) }}" alt="" style="width:35%;float:left;height:55px;">
                        <span style="margin-top:17px">{{ $item->name }}</span>
                    </a>
                </div>
            @endforeach
        </div>

    </div>

<br>
@endsection


