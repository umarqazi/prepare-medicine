@extends('frontend.master-frontend')
@section('content')

<div class='container'>
    <div class='page_banner_img_common'>
        <img src='/frontend/images/pages-banner.png' class='img-fluid'>
        <div class='overlay__'>
            <p>Password Reset</p>
        </div>
    </div>
</div>

@endsection
