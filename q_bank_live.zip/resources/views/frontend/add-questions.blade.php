@extends('frontend.master-frontend')
@section('content')

<br>
{{--  data fetch from Database !!  --}}

    <div class="container">
        <div class='page_banner_img_common'>
            <img src='/frontend/images/pages-banner.png' class='img-fluid'>
            <div class='overlay__'>
                <p>Plab Community Add Question</p>
            </div>
        </div>
        
        <h2 class="text-center" style="font-size: 35px;text-align: center;">
            Add Questions to Plab Community
        </h2>
        <br>
        <div class="col-sm-12">
            <p class="text-justify">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </p>
        </div>
        <br><br>
        {{-- <div class="row" style="float:right;">
            <div style="margin-right:5px;">
                <a href="{{ url('user/question/single/'.Auth::user()->id) }}" class="btn btn-spinner col-12 bg-info">View Single Question</a>
            </div>
            <div style="margin-left:5px;">
                <a href="{{ url('user/question/multi/'.Auth::user()->id) }}" class="btn btn-spinner col-12 bg-info">View Multichoice Question</a>
            </div>
        </div>
        <br><br><br>
        <div class="row">
            <div class="col-sm-6">
                <a href="{{ url('user/question/add/single') }}" class="btn btn-spinner col-12">Add Question</a>
            </div>
            <div class="col-sm-6">
                <a href="{{ url('user/question/add/multi') }}" class="btn btn-spinner col-12">Add Multichoice Question</a>
            </div>
        </div> --}}
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <a href="{{ url('user/question/add/single') }}" class="btn btn-spinner col-12" style="
                        background: green;
                        text-transform: uppercase;
                        border-radius: 5px;
                        box-sizing: border-box;
                        box-shadow: 0px 0px 20px 0px #444;
                    ">Add Question</a>
                </div>
            </div>
    </div>



<br>
@endsection
