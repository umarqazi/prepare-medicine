<?php echo e($slot); ?>

<?php /**PATH E:\project\question_bank\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>