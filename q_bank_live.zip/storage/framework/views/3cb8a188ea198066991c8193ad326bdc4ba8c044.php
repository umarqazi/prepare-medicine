<?php $__env->startSection('js-css'); ?>
    <style>
        /***********************************************/
        /***************** Accordion ********************/
        /***********************************************/
        @import  url('https://fonts.googleapis.com/css?family=Tajawal');
        @import  url('https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css');

        section{
            padding: 60px 0;
        }

        #accordion-style-1 h1,
        #accordion-style-1 a{
            color:#63BA52;
        }
        #accordion-style-1 .btn-link {
            font-weight: 400;
            color: #63BA52;
            background-color: transparent;
            text-decoration: none !important;
            font-size: 16px;
            font-weight: bold;
            padding-left: 25px;
        }

        #accordion-style-1 .card-body {
            border-top: 2px solid #63BA52;
        }

        #accordion-style-1 .card-header .btn.collapsed .fa.main{
            display:none;
        }

        #accordion-style-1 .card-header .btn .fa.main{
            background: #F7F7F7;
            margin-left: 26px;
            color: #63BA52;
            width: 15px;
            height: 20px;
            position: absolute;
            left: -1px;
            top: 10px;
            border-top-right-radius: 7px;
            border-bottom-right-radius: 7px;
            display:block;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    
    
        
        
    
    <div class="container-fluid bg-gray" id="accordion-style-1">
        <div class="container">
            <section>
                <div class="row">
                    <div class="col-10 mx-auto">
                        <h3 class="text-green mb-4 ">Frequently Asked Questions</h3>
                    </div>
                    <div class="col-10 mx-auto">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                  <i class="fa fa-angle-double-down main"></i><i class="fa fa-angle-double-right mr-3"></i>Lorem Ipsum is simply dummy text
                                </button>
                              </h5>
                                </div>
    
                                <div id="collapseOne" class="collapse hide fade" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, reprehenderit hic consequatur qui doloribus a, quasi modi ut, nisi fugit ex. Ex alias quibusdam magni hic architecto ipsam veniam quae, fugit error repellendus quis nesciunt earum beatae maxime dolore, itaque modi eveniet distinctio esse odit cumque! Dolores, quam. Consequuntur praesentium animi reprehenderit nobis dolorum sapiente explicabo quibusdam, ducimus hic sunt nostrum quasi maiores a distinctio rerum consequatur placeat dicta ex recusandae, eaque commodi ut. Harum, officiis cupiditate laboriosam esse temporibus praesentium! Deserunt laboriosam officia, eius dolore officiis fuga at earum odit nihil quisquam quibusdam! Repellendus dolor nesciunt necessitatibus delectus? Totam?
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#col2" aria-expanded="true" aria-controls="collapseOne">
                                  <i class="fa fa-angle-double-down main"></i><i class="fa fa-angle-double-right mr-3"></i>Lorem Ipsum is simply dummy text
                                </button>
                              </h5>
                                </div>
    
                                <div id="col2" class="collapse hide fade" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, reprehenderit hic consequatur qui doloribus a, quasi modi ut, nisi fugit ex. Ex alias quibusdam magni hic architecto ipsam veniam quae, fugit error repellendus quis nesciunt earum beatae maxime dolore, itaque modi eveniet distinctio esse odit cumque! Dolores, quam. Consequuntur praesentium animi reprehenderit nobis dolorum sapiente explicabo quibusdam, ducimus hic sunt nostrum quasi maiores a distinctio rerum consequatur placeat dicta ex recusandae, eaque commodi ut. Harum, officiis cupiditate laboriosam esse temporibus praesentium! Deserunt laboriosam officia, eius dolore officiis fuga at earum odit nihil quisquam quibusdam! Repellendus dolor nesciunt necessitatibus delectus? Totam?
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#col3" aria-expanded="true" aria-controls="collapseOne">
                                  <i class="fa fa-angle-double-down main"></i><i class="fa fa-angle-double-right mr-3"></i>Lorem Ipsum is simply dummy text
                                </button>
                              </h5>
                                </div>
    
                                <div id="col3" class="collapse hide fade" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, reprehenderit hic consequatur qui doloribus a, quasi modi ut, nisi fugit ex. Ex alias quibusdam magni hic architecto ipsam veniam quae, fugit error repellendus quis nesciunt earum beatae maxime dolore, itaque modi eveniet distinctio esse odit cumque! Dolores, quam. Consequuntur praesentium animi reprehenderit nobis dolorum sapiente explicabo quibusdam, ducimus hic sunt nostrum quasi maiores a distinctio rerum consequatur placeat dicta ex recusandae, eaque commodi ut. Harum, officiis cupiditate laboriosam esse temporibus praesentium! Deserunt laboriosam officia, eius dolore officiis fuga at earum odit nihil quisquam quibusdam! Repellendus dolor nesciunt necessitatibus delectus? Totam?
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>	
                </div>
                <br>
                <div class="row">
                    <div class="col-10 mx-auto">
                        <h3 class="text-green mb-4 ">Frequently Asked Questions</h3>
                    </div>
                    <div class="col-10 mx-auto">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#col4" aria-expanded="true" aria-controls="collapseOne">
                                  <i class="fa fa-angle-double-down main"></i><i class="fa fa-angle-double-right mr-3"></i>Lorem Ipsum is simply dummy text
                                </button>
                              </h5>
                                </div>
    
                                <div id="col4" class="collapse hide fade" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, reprehenderit hic consequatur qui doloribus a, quasi modi ut, nisi fugit ex. Ex alias quibusdam magni hic architecto ipsam veniam quae, fugit error repellendus quis nesciunt earum beatae maxime dolore, itaque modi eveniet distinctio esse odit cumque! Dolores, quam. Consequuntur praesentium animi reprehenderit nobis dolorum sapiente explicabo quibusdam, ducimus hic sunt nostrum quasi maiores a distinctio rerum consequatur placeat dicta ex recusandae, eaque commodi ut. Harum, officiis cupiditate laboriosam esse temporibus praesentium! Deserunt laboriosam officia, eius dolore officiis fuga at earum odit nihil quisquam quibusdam! Repellendus dolor nesciunt necessitatibus delectus? Totam?
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>	
                </div>
                <br>
                <div class="row">
                    <div class="col-10 mx-auto">
                        <h3 class="text-green mb-4 ">Frequently Asked Questions</h3>
                    </div>
                    <div class="col-10 mx-auto">
                        <div class="accordion" id="accordionExample">
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#col5" aria-expanded="true" aria-controls="collapseOne">
                                  <i class="fa fa-angle-double-down main"></i><i class="fa fa-angle-double-right mr-3"></i>Lorem Ipsum is simply dummy text
                                </button>
                              </h5>
                                </div>
    
                                <div id="col5" class="collapse hide fade" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, reprehenderit hic consequatur qui doloribus a, quasi modi ut, nisi fugit ex. Ex alias quibusdam magni hic architecto ipsam veniam quae, fugit error repellendus quis nesciunt earum beatae maxime dolore, itaque modi eveniet distinctio esse odit cumque! Dolores, quam. Consequuntur praesentium animi reprehenderit nobis dolorum sapiente explicabo quibusdam, ducimus hic sunt nostrum quasi maiores a distinctio rerum consequatur placeat dicta ex recusandae, eaque commodi ut. Harum, officiis cupiditate laboriosam esse temporibus praesentium! Deserunt laboriosam officia, eius dolore officiis fuga at earum odit nihil quisquam quibusdam! Repellendus dolor nesciunt necessitatibus delectus? Totam?
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#col6" aria-expanded="true" aria-controls="collapseOne">
                                  <i class="fa fa-angle-double-down main"></i><i class="fa fa-angle-double-right mr-3"></i>Lorem Ipsum is simply dummy text
                                </button>
                              </h5>
                                </div>
    
                                <div id="col6" class="collapse hide fade" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, reprehenderit hic consequatur qui doloribus a, quasi modi ut, nisi fugit ex. Ex alias quibusdam magni hic architecto ipsam veniam quae, fugit error repellendus quis nesciunt earum beatae maxime dolore, itaque modi eveniet distinctio esse odit cumque! Dolores, quam. Consequuntur praesentium animi reprehenderit nobis dolorum sapiente explicabo quibusdam, ducimus hic sunt nostrum quasi maiores a distinctio rerum consequatur placeat dicta ex recusandae, eaque commodi ut. Harum, officiis cupiditate laboriosam esse temporibus praesentium! Deserunt laboriosam officia, eius dolore officiis fuga at earum odit nihil quisquam quibusdam! Repellendus dolor nesciunt necessitatibus delectus? Totam?
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="headingOne">
                                    <h5 class="mb-0">
                                <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#col7" aria-expanded="true" aria-controls="collapseOne">
                                  <i class="fa fa-angle-double-down main"></i><i class="fa fa-angle-double-right mr-3"></i>Lorem Ipsum is simply dummy text
                                </button>
                              </h5>
                                </div>
    
                                <div id="col7" class="collapse hide fade" aria-labelledby="headingOne" data-parent="#accordionExample">
                                    <div class="card-body">
                                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque, reprehenderit hic consequatur qui doloribus a, quasi modi ut, nisi fugit ex. Ex alias quibusdam magni hic architecto ipsam veniam quae, fugit error repellendus quis nesciunt earum beatae maxime dolore, itaque modi eveniet distinctio esse odit cumque! Dolores, quam. Consequuntur praesentium animi reprehenderit nobis dolorum sapiente explicabo quibusdam, ducimus hic sunt nostrum quasi maiores a distinctio rerum consequatur placeat dicta ex recusandae, eaque commodi ut. Harum, officiis cupiditate laboriosam esse temporibus praesentium! Deserunt laboriosam officia, eius dolore officiis fuga at earum odit nihil quisquam quibusdam! Repellendus dolor nesciunt necessitatibus delectus? Totam?
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>	
                </div>
                <br>
                
            </section>
        </div>
    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\question_bank\resources\views/frontend/faq.blade.php ENDPATH**/ ?>