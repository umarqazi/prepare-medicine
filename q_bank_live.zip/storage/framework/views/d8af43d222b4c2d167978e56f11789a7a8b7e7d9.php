<?php $__env->startSection('js-css'); ?>
    <style>
        .panel-white{
            background: white;
            padding: 10px;
        }
        .btn-left{
            float: right;
        }
        .delete{
            color: red;
            margin-left: 5px;
        }
        .edit , .delete{
            font-size: 25px;
        }
        .edit {
            cursor: pointer;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="panel panel-white">
    <div class="panel-heading clearfix">
        <h4 class="panel-title">Facebook Group</h4>
    </div>
    <div class="panel-heading clearfix btn-left">
        <button class="btn btn-info" data-toggle="modal" data-target="#AddCat">Add Facebook Group</button>
    </div>
    <br><br>
    <div class="panel-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Link</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($data->firstItem()+$key); ?></th>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->link); ?></td>
                            <td>
                                <a data-toggle="modal" data-target="#EditCat<?php echo e($item->id); ?>"><i class="fa fa-edit edit"></i></a>
                                <a href="<?php echo e(url('admin/Community/drop/'.$item->id)); ?>"><i class="fa fa-remove delete"></i></a>
                            </td>
                        </tr>

                        <!-- Modal -->
                        <div class="modal fade" id="EditCat<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Edit Facebook Group</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(url('admin/Community/facebook/edit/'.$item->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Group Name</label>
                                            <input type="text" class="form-control" placeholder="Ex : Global.." name="name" value="<?php echo e($item->name); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Link</label>
                                            <input type="text" class="form-control" name="link" value="<?php echo e($item->link); ?>">
                                        </div>
                                        <input type="submit" value="Place It" class="btn btn-success col-12">
                                    </form>
                                </div>
                            </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <span><?php echo e($data->links()); ?></span>
    </div>
</div>>


    <!-- Modal -->
    <div class="modal fade" id="AddCat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Add Facebook Group</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(url('admin/Community/facebook/add')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Group Name</label>
                        <input type="text" class="form-control" placeholder="Ex : Global.." name="name">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Link</label>
                        <input type="text" class="form-control" name="link">
                    </div>
                    <input type="submit" value="Place It" class="btn btn-success col-12">
                </form>
            </div>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\question_bank\resources\views/backend/facebook.blade.php ENDPATH**/ ?>