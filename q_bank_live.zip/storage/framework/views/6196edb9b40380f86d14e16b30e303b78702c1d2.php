<?php $__env->startSection('content'); ?>

<div class='container'>
    
    <div class='page_banner_img_common'>
        <img src='/frontend/images/pages-banner.png' class='img-fluid'>
        <div class='overlay__'>
            <p>All Notes</p>
        </div>
    </div>
    
    <div class="row">
        <?php if(!$blogs->isEmpty()): ?>
        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4  col-md-6 col-12">
                <!-- single-courses -->
                <div class="single-our-blog mt--30">
                    <div class="our-blog-image">
                        <a href="#"><img src="<?php echo e(url('storage/blog/'.$blog->featured_img)); ?>" alt=""></a>
                        <span class="in-our-blog-icon">
                            <img src="<?php echo e(url('frontend/images/icon/our-blog-01.png')); ?>" alt="">
                        </span>
                    </div>
                    <div class="our-blog-contnet">
                        <h5><a href=""><?php echo e($blog->title); ?></a></h5>
                        <div class="post_meta">
                            <!-- <ul>
                                <li><p>By: <a href="#">Sekh Rana</a></p></li>
                                <li><p>15 Fab 2018</p></li>
                            </ul> -->
                        </div>
                        <div class="text-justify">
                            <?php echo str_limit($blog->description, 110); ?>
                        </div>
                        
                        
                        <div class="button-block">
                            <a href="<?php echo e(route('blogDetails', $blog->id)); ?>" class="botton-border">Read more</a>
                        </div>
                    </div>
                </div><!--// single-courses -->
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </div>
    
    <div class='col-12'>
        <?php echo $blogs->render(); ?>

    </div>
    <br/>
</div>
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/plabone.preparemedicine.com/resources/views/frontend/blog/blog-posts.blade.php ENDPATH**/ ?>