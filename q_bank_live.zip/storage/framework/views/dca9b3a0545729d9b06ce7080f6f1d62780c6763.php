<!doctype html>
<html class="no-js" lang="en">


<!-- Mirrored from demo.hasthemes.com/eduhas-preview/eduhas/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 24 Sep 2019 18:47:30 GMT -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Home || Eduhas - Education Bootstrap 4 Template</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('frontend/images/favicon.ico')); ?>">

    <!-- CSS
    ========================= -->

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/bootstrap.min.css')); ?>">

    <!-- Fonts CSS -->
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/material-design-iconic-font.min.css')); ?>">
    <link href="//stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <!-- Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/plugins.css')); ?>">

    <!-- Main Style CSS -->
    <link rel="stylesheet" href="<?php echo e(url('frontend/css/style.css')); ?>">

    <!-- Modernizer JS -->
    <script src="<?php echo e(url('frontend/js/vendor/modernizr-3.6.0.min.js')); ?>"></script>
    <style>
        .dropdown-submenu {
        position: relative;
        }

        .dropdown-submenu>.dropdown-menu {
        top: 0;
        left: 100%;
        margin-top: -6px;
        margin-left: 15px;
        padding: 10px;
        -webkit-border-radius: 0 6px 6px 6px;
        -moz-border-radius: 0 6px 6px 6px;
        border-radius: 0 6px 6px 6px;
        }

        .dropdown-submenu:hover>.dropdown-menu {
        display: block;
        }

        .dropdown-submenu>a:after {
        display: block;
        content: " ";
        float: right;
        width: 0;
        height: 0;
        border-color: transparent;
        border-style: solid;
        border-width: 5px 0 5px 5px;
        border-left-color: #cccccc;
        margin-top: 5px;
        margin-right: -10px;
        }

        .dropdown-submenu:hover>a:after {
        border-left-color: #ffffff;
        }

        .dropdown-submenu.pull-left {
        float: none;
        }

        .dropdown-submenu.pull-left>.dropdown-menu {
        left: -100%;
        margin-left: 10px;
        -webkit-border-radius: 6px 0 6px 6px;
        -moz-border-radius: 6px 0 6px 6px;
        border-radius: 6px 0 6px 6px;
        }
    </style>
    
    <?php echo $__env->yieldContent('js-css'); ?>

</head>

<body>

<!-- Main Wrapper Start -->
<div class="main-wrapper">

    <header class="header-area">
        <!-- header-top-area -->
        <div class="header-top-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-12">

                        <!-- top-contact-info -->
                        <div class="top-contact-info">
                            <ul>
                                <li><a href="#"><i class="zmdi zmdi-phone"></i> +98 558 547 589</a></li>
                                <li><a href="#"><i class="zmdi zmdi-email"></i> education@info.com</a></li>
                            </ul>
                        </div><!--// top-contact-info -->

                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="top-info-right">

                            <!-- top-social -->
                            <div class="top-social">
                                <ul>
                                    <li><a href="#"><i class="zmdi zmdi-facebook"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-twitter"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-instagram"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-pinterest"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-rss"></i></a></li>
                                </ul>
                            </div><!--// top-social -->

                            <!-- login-and-register -->
                            <div class="login-and-register">
                                <?php if(auth()->guard()->guest()): ?>
                                    <ul>
                                        <li><a href="<?php echo e(url('login')); ?>">Login</a></li>
                                        <li><a href="<?php echo e(url('register')); ?>">Register</a></li>
                                    </ul>
                                <?php endif; ?>
                                <?php if(Auth::user()): ?>
                                    <ul>
                                        <li class="nav-item dropdown" style="background: #fff;">
                                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                                    onclick="event.preventDefault();
                                                                    document.getElementById('logout-form').submit();">
                                                    <i class="fa fa-sign-out" aria-hidden="true"></i><?php echo e(__('Logout')); ?>

                                                </a>

                                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                    <?php echo csrf_field(); ?>
                                                </form>
                                        </li>
                                    </ul>
                                <?php endif; ?>
                            </div><!--// login-and-register -->

                        </div>
                    </div>
                </div>
            </div>
        </div><!--// header-top-area -->

        <div class="header-bottom-area header-sticky header-sticky">
            <div class="container">
                <div class="row">

                    <div class="col-lg-3 col-md-5 col-6">

                        <!-- logo-area -->
                        <div class="logo-area">
                            <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(url('frontend/images/logo/logo-3.png')); ?>" alt=""></a>
                        </div><!--// logo-area -->

                    </div>

                    <div class="col-lg-9 col-md-7 col-6">

                        <div class="header-bottom-right">
                            <!-- main-menu -->
                            <div class="main-menu">
                                <nav class="main-navigation">
                                    <ul>
                                        <li class="active"><a href="<?php echo e(url('/')); ?>">Home</a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo e(url('about-us')); ?>">About Us</a></li>
                                                <li><a href="<?php echo e(url('our-team/our-team')); ?>">Our Team</a></li>
                                                <li><a href="<?php echo e(url('our-team/volunteer')); ?>">Become a Volunteer</a></li>
                                                <li><a href="<?php echo e(url('our-team/plab-exam')); ?>">About PLAB Exam</a></li>
                                                <li><a href="<?php echo e(url('our-team/plab-news')); ?>">NEWS & Updates</a></li>
                                                <li><a href="<?php echo e(url('our-team/useful-links-plab-1')); ?>">Useful Links</a></li>
                                                <li><a href="<?php echo e(url('our-team/disclaimer')); ?>">Disclaimer</a></li>
                                                <li><a href="<?php echo e(url('our-team/faq')); ?>">FAQ</a></li>
                                                <li><a href="<?php echo e(url('our-team/work-us')); ?>">Work for Us</a></li>
                                                <li><a href="<?php echo e(url('our-team/feedback')); ?>">Feedback</a></li>
                                            </ul>
                                        </li>
                                        <li><a>Q-Bank</a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo e(url('course/plab-1')); ?>">PLAB 1</a></li>
                                                <li class="dropdown-submenu"><a >MRCP</a>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="<?php echo e(url('under-onstruction')); ?>">MRCP 1</a></li>
                                                        <li><a  href="<?php echo e(url('under-onstruction')); ?>">MRCP 2</a></li>
                                                    </ul>
                                                </li>
                                                <?php if(Auth::user()): ?>
                                                <?php if(Auth::user()->role >= '2' && Auth::user()->expeir_date >= date('Y-m-d')): ?>
                                                    <li><a href="<?php echo e(url('q-bank/revision-category')); ?>">Prepare By Speciality</a></li>
                                                    <li><a href="<?php echo e(url('q-bank/revision-sub-category')); ?>">Prepare By Sub-Speciality</a></li>
                                                    <li><a href="<?php echo e(url('q-bank/flagged-questions')); ?>">Flagged Questions</a></li>
                                                    <li><a href="<?php echo e(url('q-bank/recall-exam')); ?>">Recall Exam</a></li>
                                                    <li class="dropdown-submenu"><a >MOCK Exam</a>
                                                        <ul class="dropdown-menu">
                                                            <li><a href="<?php echo e(url('q-bank/mock-exam/random-mock')); ?>">Random Mock</a></li>
                                                            <li><a  href="<?php echo e(url('q-bank/mock-exam/manual-mock')); ?>">Manual Mock</a></li>
                                                        </ul>
                                                    </li>
                                                    <li class="dropdown-submenu"><a >FRCEM</a>
                                                        <ul class="dropdown-menu">
                                                            <li><a href="#">FRCEM Primary</a></li>
                                                            <li><a  href="#">FRCEM Intermediate</a></li>
                                                        </ul>
                                                    </li>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                            </ul>
                                        </li>

                                        <li><a href="<?php echo e(url('course')); ?>">Course</a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo e(url('course/plab-1')); ?>">PLAB 1</a></li>
                                                <li><a href="<?php echo e(url('course/plab-2')); ?>">PLAB 2</a></li>
                                                <li><a href="<?php echo e(url('course-material/webinars')); ?>">Webinars</a></li>
                                                <?php if(Auth::user()): ?>
                                                    <?php if(Auth::user()->role >= '2' && Auth::user()->expeir_date >= date('Y-m-d')): ?>
                                                        <li><a href="<?php echo e(url('course-material/videos-lectures')); ?>">Videos Lectures</a></li>
                                                        <li><a href="<?php echo e(url('course-material')); ?>">Course Material</a></li>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </ul>
                                        </li>
                                        
                                        <li><a href="<?php echo e(url('community')); ?>">Plab Community</a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo e(url('community/whatsApp-groups')); ?>">WhatsApp Groups</a></li>
                                                <li><a href="<?php echo e(url('community/facebook-groups')); ?>">Facebook Groups/Page</a></li>
                                                <li><a href="<?php echo e(url('community/add-questions')); ?>">Add Questions</a></li>
                                                <li><a href="<?php echo e(url('community/community-question')); ?>">Plab Community Question</a></li>
                                            </ul>
                                        </li>
                                        <?php if(Auth::user()): ?>
                                            <li><a href="<?php echo e(url('account')); ?>">Account</a>
                                                <ul class="sub-menu">
                                                    <li><a href="<?php echo e(url('account/subscription')); ?>">Subscription</a></li>
                                                    <?php if(Auth::user()->role >= '2' && Auth::user()->expeir_date >= date('Y-m-d')): ?>
                                                        <li><a href="<?php echo e(url('account/progress')); ?>">Progress</a></li>
                                                        <li><a href="<?php echo e(url('account/account-reset')); ?>">Reset Account</a></li>
                                                        <li><a href="<?php echo e(url('account/password-reset')); ?>">Reset Password</a></li>
                                                        <li><a href="<?php echo e(url('account/notification')); ?>">Notification</a></li>
                                                    <?php endif; ?>
                                                </ul>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </nav>
                            </div><!--// main-menu -->

                        </div>
                    </div>

                     <div class="col">
                        <!-- mobile-menu start -->
                        <div class="mobile-menu d-block d-lg-none"></div>
                        <!-- mobile-menu end -->
                    </div>

                </div>
            </div>
        </div>

    </header>



    <?php echo $__env->yieldContent('content'); ?>



        <!-- Footer Area -->
        <footer class="footer-area">

            <!-- Footer Top Area -->
            <div class="footer-top section-pb section-pt-60">
                <div class="container">
                    <div class="row">

                        <div class="col-lg-4 col-md-6 mt--60">
                            <div class="footer-single-block">
                                <div class="footer-logo">
                                    <a href="index.html"><img src="<?php echo e(url('frontend/images/logo/Asset 5@4x.png')); ?>" alt=""></a>
                                </div>
                                <p class="footer-dec">If you are going to use a passage LorIsum, you anythirassing hidden in the middle
                                of text. Iators on the Internet tend to.</p>
                                <ul class="footer-social-link">
                                    <li><a href="#"><i class="zmdi zmdi-facebook"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-rss"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-instagram"></i></a></li>
                                    <li><a href="#"><i class="zmdi zmdi-pinterest"></i></a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-2 col-md-6  mt--60">
                            <div class="footer-block">
                                <h5>Quick Links</h5>
                                <ul class="footer-list">
                                    <li><a href="#">Privacy Statement</a></li>
                                    <li><a href="#">Teaching Staff</a></li>
                                    <li><a href="#">Report Copyright</a></li>
                                    <li><a href="#">Community</a></li>
                                    <li><a href="#">Schedule</a></li>
                                    <li><a href="#">Discount Program</a></li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 mt--60">
                            <div class="footer-block">
                                <h5>Popular Courses</h5>
                                <ul class="footer-courses">
                                    <li>
                                        <div class="courses-image">
                                            <a href="#"><img src="<?php echo e(url('frontend/images/blog/small-tham/blog-01.jpg')); ?>" alt=""></a>
                                        </div>
                                        <div class="courses-nifo">
                                            <h5><a href="#">Department of
                                                Science.</a></h5>
                                            <p>Duration : 4 Yr</p>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="courses-image">
                                            <a href="#"><img src="<?php echo e(url('frontend/images/blog/small-tham/blog-02.jpg')); ?>" alt=""></a>
                                        </div>
                                        <div class="courses-nifo">
                                            <h5><a href="#">Combined  With
                                                a Handfull</a></h5>
                                            <p>Duration : 2 Yr</p>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>

                        <div class="col-lg-3 col-md-6 mt--60">
                            <div class="footer-block">
                                <h5>NEWSLETTER</h5>
                                <div class="newsletter-wrap">
                                    <p>Enter your email and we'll send you more information of.</p>
                                    <div class="newsletter-input-box">
                                        <form action="#">
                                            <input type="text" placeholder="Your email address">
                                            <button class="newsletter-button"><i class="zmdi zmdi-mail-send"></i></button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div><!--// Footer Top Area -->

            <!-- Footer-bottom Area -->
            <div class="footer-bottom">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="copy-right pt--10 pb--10 text-center text-white">
                                <p>Copyright© 2018 <a href="#">EduHas</a>,Designed by <span>HasTech</span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div><!--// Footer-botton Area -->

        </footer>
        <!--// Footer Area -->

    </div>
    <!-- Main Wrapper End -->

    <!-- JS
    ============================================ -->

    <!-- jQuery JS -->
    <script src="<?php echo e(url('frontend/js/vendor/jquery-3.3.1.min.js')); ?>"></script>
    <!-- Popper JS -->
    <script src="<?php echo e(url('frontend/js/popper.min.js')); ?>"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(url('frontend/js/bootstrap.min.js')); ?>"></script>
    <!-- Plugins JS -->
    <script src="<?php echo e(url('frontend/js/plugins.js')); ?>"></script>
    <!-- Ajax Mail -->
    <script src="<?php echo e(url('frontend/js/ajax-mail.js')); ?>"></script>
    <!-- Main JS -->
    <script src="<?php echo e(url('frontend/js/main.js')); ?>"></script>
    
    <?php echo $__env->yieldContent('js'); ?>

    </body>


    <!-- Mirrored from demo.hasthemes.com/eduhas-preview/eduhas/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 24 Sep 2019 18:47:36 GMT -->
    </html>
<?php /**PATH D:\question_bank\resources\views/frontend/master-frontend.blade.php ENDPATH**/ ?>