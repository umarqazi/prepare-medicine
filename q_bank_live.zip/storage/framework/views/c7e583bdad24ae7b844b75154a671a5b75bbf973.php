<?php $__env->startSection('js-css'); ?>
    <style type="text/css">
        p{
        	text-align: justify;
        }
        h4{
        	margin-top: 30px;
        	border-bottom: 1px solid #ddd
        }

        ul{
        	display: block;
        	list-style-type: square;
        	margin-left: 25px;
        }

        .heading_{border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
            margin-bottom: 20px;
            font-size: 30px;
            text-align: center;
        }

    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="container">
        <h3 class="heading_"><?php echo e($data->title); ?></h3>

        <div class="text-center" style="margin-bottom: 30px"> 
            <img src="<?php echo e(url('storage/blog/'.$data->featured_img)); ?>">
        </div>

        <?php echo $data->description; ?>
    </div>  
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/frontend/blog-details.blade.php ENDPATH**/ ?>