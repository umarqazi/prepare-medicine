<?php $__env->startSection('js-css'); ?>
<style type="text/css">
    .existBTN{
        background-color: darkred !important;
        color: #fff !important;
        border: none !important;
        border-radius: 3px !important;
        padding: 3px 15px !important
    }
</style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<br>
<div class="container-fluid" style="padding-left: 30px; padding-right: 30px">
    <div class='page_banner_img_common'>
        <img src='/frontend/images/pages-banner.png' class='img-fluid'>
        <div class='overlay__'>
            <p>Manual Mock</p>
        </div>
    </div>
    
    <h2 style="font-size: 30px;text-align: center;">MANUAL MOCK</h2>
    <p class="text-justify">
        Loreeaqin laboriosam officia explicabo rem nobis temporibusasperiores iure nobis obcaecati, inventore, nulla cumque ipsum excepturi voluptates odit rem nisi accusamus illum. Itaque, mollitia! Nam modi, quidem at nihil beatae eaque minima perspiciatis reprehenderit.
    </p>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $expired_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key%4 == '0'): ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                        <a href="<?php echo e(url('q-bank/manual/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                            <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                            <span style="margin-top:17px">MOCK <?php echo e($key+1); ?></span>
                        </a>
                    </div>
                <?php elseif($key%3 == '0'): ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                        <a href="<?php echo e(url('q-bank/manual/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                            <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                            <span style="margin-top:17px">MOCK <?php echo e($key+1); ?></span>
                        </a>
                    </div>
                <?php elseif($key%2 == '0'): ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                        <a href="<?php echo e(url('q-bank/manual/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                            <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                            <span style="margin-top:17px">MOCK <?php echo e($key+1); ?></span>
                        </a>
                    </div>
                <?php else: ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                        <a href="<?php echo e(url('q-bank/manual/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                            <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                            <span style="margin-top:17px">MOCK <?php echo e($key+1); ?></span>
                        </a>
                    </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    <?php if($exists_data != '0'): ?>
        <?php $__currentLoopData = $continue_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                <a href="<?php echo e(url('q-bank/manual/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden">
                    <img src="<?php echo e(url('storage/photos/mock/random-mock/continue-mock.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                    <span style="margin-top:17px"><?php echo e('Continue Mock'); ?></span>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
            <button data-target="#exampleModalCenter" data-toggle="modal" type="button" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden">
                <img src="<?php echo e(url('storage/photos/mock/random-mock/new-mock.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                <span style="margin-top:17px"><?php echo e('New Mock'); ?></span>
            </button>
        </div>


        <!-- Modal -->
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Choose Specialties</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <ul class="nav nav-tabs md-tabs" id="myTabMD" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab-md" data-toggle="tab" href="#home-md" role="tab" aria-controls="home-md" aria-selected="true">Specialities</a>
                        </li>
                    </ul>
                    <div class="tab-content card p-3" id="myTabContentMD">
                        <div class="tab-pane fade show active" id="home-md" role="tabpanel" aria-labelledby="home-tab-md">
                            
                            <form action="<?php echo e(url('q-bank/manual')); ?>" method="get">
                                <input type="hidden" value="cat" name="type">
                                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="cat<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" name="search[]">
                                        <label class="custom-control-label" for="cat<?php echo e($item->id); ?>"><?php echo e($item->name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="submit" value="Continue" class="btn btn-success bg-success" style="float:right;border-radius: 4px">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn existBTN" data-dismiss="modal">Exit</button>
                </div>
            </div>
            </div>
        </div>
    <?php endif; ?>
  </div> <!-- .row end here -->
</div>


<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/preparemedicine.com/resources/views/frontend/manual-mock.blade.php ENDPATH**/ ?>