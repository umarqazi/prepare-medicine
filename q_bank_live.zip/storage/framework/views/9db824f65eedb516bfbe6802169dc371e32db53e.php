<?php $__env->startSection('js-css'); ?>
    <style>
        .panel-white{
            background: white;
            padding: 10px;
        }
        .btn-left{
            float: right;
        }
        .btn{
            padding: 5px 15px;
            border-radius: 4px;
            margin-top:2px;
            margin-right:2px;
            width:45px;
        }

        .delete{
            background-color: red;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class='page_banner_img_common'>
            <img src='/frontend/images/pages-banner.png' class='img-fluid'>
            <div class='overlay__'>
                <p>Flagged Questions</p>
            </div>
        </div>
        
        <div class="panel panel-white">
            <div class="panel-heading clearfix">
                <h4 class="panel-title text-center">Flagged Questions</h4>
            </div>
            <br>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Question</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($data->firstItem()+$key); ?></th>
                                    <td><?php echo $item->flag_question->question; ?></td>
                                    <td>
                                        <a title="View" class="btn" href="<?php echo e(url('q-bank/flag/question/'.$item->ques_id)); ?>" ><i class="fas fa-eye"></i></a>
                                        <a title="Remove" class="btn delete" href="<?php echo e(url('q-bank/drop/flag/'.$item->id)); ?>"><i class="fas fa-times"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <span><?php echo e($data->links()); ?></span>
            </div>
        </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/preparemedicine.com/resources/views/frontend/flagged-questions.blade.php ENDPATH**/ ?>