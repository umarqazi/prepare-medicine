<?php $__env->startSection('content'); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/backend/index.blade.php ENDPATH**/ ?>