<?php $__env->startSection('js-css'); ?>

    <style>
        .user-name{
            color:#63BA52;
            display: ruby;
        }
        .user-feedback{
            margin-left: 25px;
        }
        .edit-btn{
            color: green;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
    <br><br>
    <div class="container">
        <div class="row">
            <div class="well" style="width:100%">
                <h3 class="text-center">Notification</h3>
                <br>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group">
                        <div class="col-md-12">
                            <h4 class="list-group-item-heading  user-name" data-toggle="collapse" data-target="#desc<?php echo e($item->id); ?>" style="cursor:pointer"><?php echo e($item->title); ?></h4>
                            <div class="alert alert-info alert-dismissible list-group-item-text user-feedback collapse" id="desc<?php echo e($item->id); ?>" style="background:rgb(245, 245, 245); border: 1px solid azure;">
                                <p class="" > <?php echo $item->description; ?> </p>
                            </div>
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project emon vai\question_bank\resources\views/frontend/notification.blade.php ENDPATH**/ ?>