<?php $__env->startSection('js-css'); ?>
    <script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
    <style>
        .panel-white{
            background: white;
            padding: 10px;
        }
        .btn-left{
            float: right;
        }
        .delete{
            color: red;
            margin-left: 5px;
        }
        .edit , .delete{
            font-size: 25px;
        }
        .edit {
            cursor: pointer;
        }


        .btn_custom_style{
            background-color: #ddd;
            color: #000
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="panel panel-white">
    <div class="panel-heading clearfix">
        <h4 class="panel-title">Notification</h4>
    </div>
    <div class="panel-heading clearfix btn-left">
        <button class="btn btn_custom_style" data-toggle="modal" data-target="#AddCat">Send Notification</button>
    </div>
    <br><br>
    <div class="panel-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Expired</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($data->firstItem()+$key); ?></th>
                            <td><?php echo e($item->title); ?></td>
                            <td><?php echo $item->description; ?></td>
                            <td><?php echo e($item->expired); ?></td>
                            <td>
                                <a data-toggle="modal" data-target="#EditCat<?php echo e($item->id); ?>"><i class="fa fa-edit edit"></i></a>
                                <a href="<?php echo e(url('admin/notification/drop/'.$item->id)); ?>"><i class="fa fa-remove delete"></i></a>
                            </td>
                        </tr>

                        <!-- Modal -->
                        <div class="modal fade" id="EditCat<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Add Category</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(url('admin/notification/edit')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Notification Title</label>
                                            <input type="text" class="form-control" placeholder="Ex : Biology.." name="title" value="<?php echo e($item->title); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Notification Description</label>
                                            <textarea class="form-control my-editor" placeholder="Ex : Biology.." name="description"><?php echo $item->description; ?></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Notification Expired</label>
                                            <input type="date" class="form-control" name="expired" value="<?php echo e($item->expired); ?>">
                                        </div>
                                        <input type="submit" value="Place It" class="btn btn-success col-12">
                                    </form>
                                </div>
                            </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <span><?php echo e($data->links()); ?></span>
    </div>
</div>

    <!-- Modal -->
    <div class="modal fade" id="AddCat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Add Category</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(url('admin/notification/add')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Notification Title</label>
                        <input type="text" class="form-control" placeholder="Ex : Biology.." name="title" >
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Notification Description</label>
                        <textarea class="form-control my-editor" placeholder="Ex : Biology.." name="description"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Notification Expired</label>
                        <input type="date" class="form-control" name="expired">
                    </div>
                    <input type="submit" value="Place It" class="btn btn-success col-12">
                </form>
            </div>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
    
    <script>
        var editor_config = {
            path_absolute : "/",
            selector: "textarea.my-editor",
            plugins: [
            "advlist autolink lists link image charmap print preview hr anchor pagebreak",
            "searchreplace wordcount visualblocks visualchars code fullscreen",
            "insertdatetime media nonbreaking save table contextmenu directionality",
            "emoticons template paste textcolor colorpicker textpattern"
            ],
            toolbar: "insertfile undo redo | styleselect | bold italic | fontsizeselect | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image media",
            relative_urls: false,
            file_browser_callback : function(field_name, url, type, win) {
            var x = window.innerWidth || document.documentElement.clientWidth || document.getElementsByTagName('body')[0].clientWidth;
            var y = window.innerHeight|| document.documentElement.clientHeight|| document.getElementsByTagName('body')[0].clientHeight;

            var cmsURL = editor_config.path_absolute + 'laravel-filemanager?field_name=' + field_name;
            if (type == 'image') {
                cmsURL = cmsURL + "&type=Images";
            } else {
                cmsURL = cmsURL + "&type=Files";
            }

            tinyMCE.activeEditor.windowManager.open({
                file : cmsURL,
                title : 'Filemanager',
                width : x * 0.8,
                height : y * 0.8,
                resizable : "yes",
                close_previous : "no"
            });
            }
        };

        tinymce.init(editor_config);
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/backend/notification.blade.php ENDPATH**/ ?>