<?php $__env->startSection('js-css'); ?>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <style>
        .panel-white{
            background: white;
            padding: 10px;
        }
        .btn-left{
            float: right;
        }
        .delete{
            color: red;
            margin-left: 5px;
        }
        .edit , .delete{
            font-size: 25px;
        }
        .edit {
            cursor: pointer;
        }


        .btn_custom_style{
            background-color: #ddd;
            color: #000
        }

    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="panel panel-white">
    <div class="panel-heading clearfix">
        <h4 class="panel-title">Subscriber List</h4>
    </div>
    <br><br>
    <div class="panel-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>ID</th>
                        <th>Plan</th>
                        <th>Expire Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($key++); ?></th>
                            <td><?php echo e($item->f_name); ?> <?php echo e($item->s_name); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td><?php echo e($item->customer_id); ?></td>
                            <td>
                                <?php if($item->role == 2): ?>
                                    <?php echo e('Trail'); ?>

                                <?php elseif($item->role == 3): ?>
                                    <?php echo e('Refugees Doctors'); ?>

                                <?php elseif($item->role == 5): ?>
                                    <?php echo e('Basic'); ?>

                                <?php elseif($item->role == 6): ?>
                                    <?php echo e('Standard'); ?>

                                <?php elseif($item->role == 7): ?>
                                    <?php echo e('Advance'); ?>

                                 <?php elseif($item->role == 8): ?>
                                    <?php echo e('Professional'); ?>

                                <?php else: ?>
                                    <?php echo e('Wrong'); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e(date('d F Y', strtotime($item->expeir_date))); ?>

                            </td>
                            <td>
                                <a data-toggle="modal" data-target="#detailsModal<?php echo e($item->id); ?>"><i class="fa fa-eye eye"></i></a>
                                <!-- Modal -->
                        <div class="modal fade" id="detailsModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel<?php echo e($item->id); ?>">Detials</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <th>Name</th>
                                                <td><?php echo e($item->f_name); ?> <?php echo e($item->s_name); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Email</th>
                                                <td><?php echo e($item->email); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Plan</th>
                                                <td>
                                                    <?php if($item->role == 2): ?>
                                                        <?php echo e('Trail'); ?>

                                                    <?php elseif($item->role == 3): ?>
                                                        <?php echo e('Refugees Doctors'); ?>

                                                    <?php elseif($item->role == 5): ?>
                                                        <?php echo e('Basic'); ?>

                                                    <?php elseif($item->role == 6): ?>
                                                        <?php echo e('Standard'); ?>

                                                    <?php elseif($item->role == 7): ?>
                                                        <?php echo e('Advance'); ?>

                                                     <?php elseif($item->role == 8): ?>
                                                        <?php echo e('Professional'); ?>

                                                    <?php else: ?>
                                                        <?php echo e('Wrong'); ?>

                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php if($item->role != 2 && $item->role != 3): ?>
                                            <tr>
                                                <th>Customer ID</th>
                                                <td><?php echo e($item->customer_id); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Transaction ID</th>
                                                <td><?php echo e($item->trxID); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Paid Amount</th>
                                                <td><?php echo e($item->amount_paid); ?></td>
                                            </tr>
                                            <tr>
                                                <th>Subscribe at</th>
                                                <td><?php echo e(date('d F Y', strtotime($item->paid_at))); ?></td>
                                            </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <th>Expire Date</th>
                                                <td><?php echo e(date('d F Y', strtotime($item->expeir_date))); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            </div>
                        </div>
                            </td>
                        </tr>

                        

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <span><?php echo $data->render(); ?></span>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/backend/subscriber-list.blade.php ENDPATH**/ ?>