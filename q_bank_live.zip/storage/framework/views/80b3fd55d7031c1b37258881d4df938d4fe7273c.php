<?php $__env->startSection('js-css'); ?>

    <style>
        .user-name-hidden{
            color:red;
            display: ruby;
        }
        .user-name-show{
            color:green;
            display: ruby;
        }
        .user-feedback{
            margin-left: 25px;
        }
        .edit-btn{
            color: green;
        }
        .panel-warning{
            background: #fff;
            padding: 10px
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
    <br><br>
    <div class="panel panel-warning">
        <div class="panel-body">
            <div class="container">
                <div class="row">
                    <div class="well">
                        <h2 class="text-center">Feedback</h2>
                        <br>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->status == '1'): ?>
                                <div class="list-group">
                                    <div class="col-md-12">
                                        <h4 class="list-group-item-heading  user-name-show">
                                            <?php echo e($item->user_name); ?>

                                            <?php if($item->status == '1'): ?>
                                                <a href="<?php echo e(url('admin/feedback/hide/'.$item->id )); ?>"><i class="fa fa-eye-slash edit-btn"></i></a>
                                            <?php elseif($item->status == '2'): ?>
                                                <a href="<?php echo e(url('admin/feedback/show/'.$item->id )); ?>"><i class="fa fa-eye edit-btn"></i></a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(url('admin/feedback/drop/'.$item->id)); ?>"><i class="fa fa-remove"></i></a>
                                        </h4>
                                        <p class="list-group-item-text user-feedback"> <?php echo e($item->feedback); ?> </p>
                                    </div>
                                </div>
                                <br>
                            <?php else: ?>
                                <div class="list-group">
                                    <div class="col-md-12">
                                        <h4 class="list-group-item-heading  user-name-hidden">
                                            <?php echo e($item->user_name); ?>

                                            <?php if($item->status == '1'): ?>
                                                <a href="<?php echo e(url('admin/feedback/hide/'.$item->id )); ?>"><i class="fa fa-eye-slash edit-btn"></i></a>
                                            <?php elseif($item->status == '2'): ?>
                                                <a href="<?php echo e(url('admin/feedback/show/'.$item->id )); ?>"><i class="fa fa-eye edit-btn"></i></a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(url('admin/feedback/drop/'.$item->id)); ?>"><i class="fa fa-remove"></i></a>
                                        </h4>
                                        <p class="list-group-item-text user-feedback"> <?php echo e($item->feedback); ?> </p>
                                    </div>
                                </div>
                                <br>
                            <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <br>
                <span>
                    <?php echo e($data->links()); ?>

                </span>
            </div>
        </div>
    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Question_Bank\resources\views/backend/admin-feedback.blade.php ENDPATH**/ ?>