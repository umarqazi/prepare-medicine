<?php $__env->startSection('js-css'); ?>

    <style>
    	.heading{
		    margin-bottom: 70px;
		    border-bottom: 1px solid #ddd;
		    padding-bottom: 10px;
		    text-align: center;
		    text-transform: uppercase;
    	}
    	.thankYou{
    		background-color: green;
    		color: #fff;
    		font-weight: bold;
    		text-transform: uppercase;
    		text-align: center;
    		padding: 15px 10px;
    	}
    </style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <br><br>
    <div class="container">
        <h4 class="heading">Status</h4>

        <div class="row">
        	<div class="col-md-3"></div>
        	<?php if($statusID == 1): ?>
        	<div class="col-md-6">
        		<table class="table">
        			<tr>
        				<th>Payment Status</th>
        				<td style="color: darkred">Not Paid</td>
        			</tr>
        			<tr>
        				<th>General Status</th>
        				<td style="color: #666">Unknown Error</td>
        			</tr>
        			<tr>
        				<td colspan="2">WE Are Really Sorry!! Please try agian later.</td>
        			</tr>
        		</table>
        	</div>
        	<?php elseif($statusID == 2): ?>
        	<div class="col-md-6">
        		<h5 class="thankYou">Thank You</h5>
        		<table class="table">
        			<tr>
        				<th>Payment Status</th>
        				<td style="color: green">Paid Successfully</td>
        			</tr>
        			<tr>
        				<th>Amount</th>
        				<td>£<?php echo e(Auth::user()->amount_paid); ?></td>
        			</tr>
        			<tr>
        				<th>Your ID</th>
        				<td><?php echo e(Auth::user()->customer_id); ?></td>
        			</tr>
        			<tr>
        				<th>Subscription Plan</th>
        				<td>
        					<?php if(Auth::user()->role == 5): ?>
        					<?php echo e('Basic'); ?>

        					<?php elseif(Auth::user()->role == 6): ?>
        					<?php echo e('Standard'); ?>

        					<?php elseif(Auth::user()->role == 7): ?>
        					<?php echo e('Advance'); ?>

        					<?php elseif(Auth::user()->role == 8): ?>
        					<?php echo e('Professional'); ?>

        					<?php else: ?>
        					<?php echo e('Something Wrong'); ?>

        					<?php endif; ?>
        				</td>
        			</tr>
        			<tr>
        				<th>Subscription Expired Date</th>
        				<td>
        					<?php echo e(Auth::user()->expeir_date); ?>

        				</td>
        			</tr>
        			<tr>
        				<td colspan="2">
        					Thanks a lot to subscribe
        					<br>
        					<span style="color: red">N.B Please keep you ID safe to any inquiry about your payment or plan.</span>
        				</td>
        			</tr>
        		</table>
        	</div>

        	<?php elseif($statusID == 3): ?>
        	<div class="col-md-6">
        		<table class="table">
        			<tr>
        				<th>Payment Status</th>
        				<td style="color: darkred">Fail</td>
        			</tr>
        			<tr>
        				<th>General Status</th>
        				<td style="color: #666">Something wrong or invalid card information</td>
        			</tr>
        			<tr>
        				<td colspan="2">WE Are Really Sorry!! Please try agian later.</td>
        			</tr>
        		</table>
        	</div>
        	<?php else: ?>

        	<h4 style="color: red;"><?php echo e('Invalid Access'); ?></h4>

        	<?php endif; ?>

        	<div class="col-md-3"></div>
        </div>
    </div>
    <br><br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/frontend/paynow-status.blade.php ENDPATH**/ ?>