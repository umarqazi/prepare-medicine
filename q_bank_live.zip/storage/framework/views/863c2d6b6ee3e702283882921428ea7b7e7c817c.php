<?php $__env->startSection('js-css'); ?>

    <style>
        .user-name-hidden{
            color:red;
            display: ruby;
        }
        .user-name-show{
            color:green;
            display: ruby;
        }
        .user-feedback{
            margin-left: 25px;
        }
        .edit-btn{
            color: green;
        }
        .panel-warning{
            background: #fff;
            padding: 10px
        }
        .right{
            float: right;
        }
        .border{
            border: 10px solid green;
        }
        .block{
            display: block;
        }
        li{
            list-style-type: none;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<br><br>
<div class="panel panel-warning">
    <div class="panel-body">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border col-4 embed-responsive embed-responsive-21by9">
                            <iframe  class="col-12 embed-responsive-item" src="<?php echo e($item->path); ?>" allowfullscreen></iframe>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <br>
            <span>
                <?php echo e($data->links()); ?>

            </span>
        </div>
    </div>
</div>
<br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\question_bank\resources\views/frontend/videos-lectures.blade.php ENDPATH**/ ?>