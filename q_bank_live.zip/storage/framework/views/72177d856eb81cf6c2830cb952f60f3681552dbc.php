<?php $__env->startSection('js-css'); ?>
    <style>
        .panel-white{
            background: white;
            padding: 10px;
        }
        .btn-left{
            float: right;
        }
        .delete{
            color: red;
            margin-left: 5px;
        }
        .edit , .delete{
            font-size: 25px;
        }
        .edit {
            cursor: pointer;
        }

    </style>
    <style>
        /* chart style */
        .horizontal .progress-bar {
        float: left;
        height: 45px;
        width: 100%;
        padding: 12px 0;
        }

        .horizontal .progress-track {
        position: relative;
        width: 100%;
        height: 20px;
        background: #ebebeb;
        }

        .horizontal .progress-fill {
        position: relative;
        background: #666;
        height: 20px;
        width: 50%;
        color: #fff;
        text-align: center;
        font-family: "Lato","Verdana",sans-serif;
        font-size: 12px;
        line-height: 20px;
        }

        .rounded .progress-track,
        .rounded .progress-fill {
        border-radius: 3px;
        box-shadow: inset 0 0 5px rgba(0,0,0,.2);
        }
    </style>
    
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    
    <script type="text/javascript">
    google.charts.load('current', {'packages':['corechart']});
    // Manual Exam
    google.charts.setOnLoadCallback(Manual);
    google.charts.setOnLoadCallback(ManualS);

    function Manual() {

    var data = google.visualization.arrayToDataTable([
            ['Task', 'My Performance'],
            ['Correct',      <?php echo e($chart_data['manual'][1]); ?>],
            ['Wrong', <?php echo e(($chart_data['manual'][0]-$chart_data['manual'][1])); ?>],
        ]);

    var options = {
        title: 'My Performance',
        colors: ['#63BA52', '#E8372E'],
        is3D: true,
    };

    var chart = new google.visualization.PieChart(document.getElementById('Manual'));

    chart.draw(data, options);
    }

    function ManualS() {

    var data = google.visualization.arrayToDataTable([
            ['Task', 'All Users Performance'],
            ['Correct',      <?php echo e($chart_data['manual'][3]); ?>],
            ['Wrong', <?php echo e(($chart_data['manual'][2]-$chart_data['manual'][3])); ?>],
        ]);

    var options = {
        title: 'All Users Performance',
        colors: ['#63BA52', '#E8372E'],
        is3D: true,
    };

    var chart = new google.visualization.PieChart(document.getElementById('ManualS'));

    chart.draw(data, options);
    }
    // End Manual

    // Random Exam
    google.charts.setOnLoadCallback(Random);
    google.charts.setOnLoadCallback(RandomS);

    function Random() {

    var data = google.visualization.arrayToDataTable([
            ['Task', 'My Performance'],
            ['Correct',      <?php echo e($chart_data['random'][1]); ?>],
            ['Wrong', <?php echo e(($chart_data['random'][0]-$chart_data['random'][1])); ?>],
        ]);

    var options = {
        title: 'My Performance',
        colors: ['#63BA52', '#E8372E'],
        is3D: true,
    };

    var chart = new google.visualization.PieChart(document.getElementById('Random'));

    chart.draw(data, options);
    }

    function RandomS() {

    var data = google.visualization.arrayToDataTable([
            ['Task', 'All Users Performance'],
            ['Correct',      <?php echo e($chart_data['random'][3]); ?>],
            ['Wrong', <?php echo e(($chart_data['random'][2]-$chart_data['random'][3])); ?>],
        ]);

    var options = {
        title: 'All Users Performance',
        colors: ['#63BA52', '#E8372E'],
        is3D: true,
    };

    var chart = new google.visualization.PieChart(document.getElementById('RandomS'));

    chart.draw(data, options);
    }
    // End Random

    // Recall Exam
    google.charts.setOnLoadCallback(Recall);
    google.charts.setOnLoadCallback(RecallS);

    function Recall() {

    var data = google.visualization.arrayToDataTable([
            ['Task', 'My Performance'],
            ['Correct',      <?php echo e($chart_data['recall'][1]); ?>],
            ['Wrong', <?php echo e(($chart_data['recall'][0]-$chart_data['recall'][1])); ?>],
        ]);

    var options = {
        title: 'My Performance',
        colors: ['#63BA52', '#E8372E'],
        is3D: true,
    };

    var chart = new google.visualization.PieChart(document.getElementById('Recall'));

    chart.draw(data, options);
    }

    function RecallS() {

    var data = google.visualization.arrayToDataTable([
            ['Task', 'All Users Performance'],
            ['Correct',      <?php echo e($chart_data['recall'][3]); ?>],
            ['Wrong', <?php echo e(($chart_data['recall'][2]-$chart_data['recall'][3])); ?>],
        ]);

    var options = {
        title: 'All Users Performance',
        colors: ['#63BA52', '#E8372E'],
        is3D: true,
    };

    var chart = new google.visualization.PieChart(document.getElementById('RecallS'));

    chart.draw(data, options);
    }
    // End Recall

    // Category Exam
    google.charts.setOnLoadCallback(Category);
    google.charts.setOnLoadCallback(CategoryS);

    function Category() {

    var data = google.visualization.arrayToDataTable([
            ['Task', 'My Performance'],
            ['Correct',      <?php echo e($chart_data['category'][1]); ?>],
            ['Wrong', <?php echo e(($chart_data['category'][0]-$chart_data['category'][1])); ?>],
        ]);

    var options = {
        title: 'My Performance',
        colors: ['#63BA52', '#E8372E'],
        is3D: true,
    };

    var chart = new google.visualization.PieChart(document.getElementById('Category'));

    chart.draw(data, options);
    }

    function CategoryS() {

    var data = google.visualization.arrayToDataTable([
            ['Task', 'All Users Performance'],
            ['Correct',      <?php echo e($chart_data['category'][3]); ?>],
            ['Wrong', <?php echo e(($chart_data['category'][2]-$chart_data['category'][3])); ?>],
        ]);

    var options = {
        title: 'All Users Performance',
        colors: ['#63BA52', '#E8372E'],
        is3D: true,
    };

    var chart = new google.visualization.PieChart(document.getElementById('CategoryS'));

    chart.draw(data, options);
    }
    // End Category
    </script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="panel panel-white">
            <div class="panel-heading clearfix">
                <h4 class="panel-title">Random Progress</h4>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div id="Random" style="height: 300px; width: 100%;"></div>
                </div>
                <div class="col-md-6">
                    <div id="RandomS" style="height: 300px; width: 100%;"></div>
                </div>
            </div>
             
            <div class="m-auto">
                    <!-- Random Progress -->
                    <div class="container horizontal rounded">
                    <?php $__currentLoopData = $random; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="horizontal">
                                <p class="bg-white text-dark">Exam-<?php echo e($key+1); ?></p>
                        <div class="progress-track">
                            <div class="progress-fill">
                            <span><?php echo e(round( ($item->right_ans/$item->mockinfo_mockques->count())*100 )); ?>%</span>
                            </div>
                        </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <br><br>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Exam Name</th>
                                <th>Total Question</th>
                                <th>Right Answer</th>
                                <th>Wrong Answer</th>
                                <th>Skiped Question</th>
                                <th>Result</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $random; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td>Mock <?php echo e($key+1); ?></td>
                                    <td><?php echo e($item->mockinfo_mockques->count()); ?></td>
                                    <td><?php echo e($item->right_ans); ?></td>
                                    <td><?php echo e($item->wrong_ans); ?></td>
                                    <td><?php echo e($item->mockinfo_mockques->count()-($item->right_ans+$item->wrong_ans)); ?></td>
                                    <td><?php echo e(round( ($item->right_ans/$item->mockinfo_mockques->count())*100 )); ?>%</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="panel panel-white">
            <div class="panel-heading clearfix">
                <h4 class="panel-title">Manual Progress</h4>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div id="Manual" style="height: 300px; width: 100%;"></div>
                </div>
                <div class="col-md-6">
                    <div id="ManualS" style="height: 300px; width: 100%;"></div>
                </div>
            </div>
             
            <div class="m-auto">
                    <!-- Random Progress -->
                    <div class="container horizontal rounded">
                    <?php $__currentLoopData = $manual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="horizontal">
                        <p class="bg-white text-dark">Exam-<?php echo e($key+1); ?></p>
                        <div class="progress-track">
                            <div class="progress-fill">
                            <span><?php echo e(round( ($item->right_ans/$item->mockinfo_mockques->count())*100 )); ?>%</span>
                            </div>
                        </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <br><br>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Exam Name</th>
                                <th>Total Question</th>
                                <th>Right Answer</th>
                                <th>Wrong Answer</th>
                                <th>Skiped Question</th>
                                <th>Result</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $manual; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td>Mock <?php echo e($key+1); ?></td>
                                    <td><?php echo e($item->mockinfo_mockques->count()); ?></td>
                                    <td><?php echo e($item->right_ans); ?></td>
                                    <td><?php echo e($item->wrong_ans); ?></td>
                                    <td><?php echo e($item->mockinfo_mockques->count()-($item->right_ans+$item->wrong_ans)); ?></td>
                                    <td><?php echo e(round( ($item->right_ans/$item->mockinfo_mockques->count())*100 )); ?>%</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="panel panel-white">
            <div class="panel-heading clearfix">
                <h4 class="panel-title">Recall Progress</h4>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div id="Recall" style="height: 300px; width: 100%;"></div>
                </div>
                <div class="col-md-6">
                    <div id="RecallS" style="height: 300px; width: 100%;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="panel panel-white">
            <div class="panel-heading clearfix">
                <h4 class="panel-title">Speciality Progress</h4>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div id="Category" style="height: 300px; width: 100%;"></div>
                </div>
                <div class="col-md-6">
                    <div id="CategoryS" style="height: 300px; width: 100%;"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        // chart js
        $('.horizontal .progress-fill span').each(function(){
            var percent = $(this).html();
            $(this).parent().css('width', percent);
        });


        $('.vertical .progress-fill span').each(function(){
            var percent = $(this).html();
            var pTop = 100 - ( percent.slice(0, percent.length - 1) ) + "%";
            $(this).parent().css({
                'height' : percent,
                'top' : pTop
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\question_bank\resources\views/frontend/progress.blade.php ENDPATH**/ ?>