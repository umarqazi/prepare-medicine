<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class community extends Model
{
    protected $fillable = ['name','link'];
}
