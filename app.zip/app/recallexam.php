<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class recallexam extends Model
{
    //
}
