<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="text-left logo_in_pages" style="margin-bottom: 15px">
                <img src="<?php echo e(asset('frontend/images/logo/logo-3.png')); ?>" style="width: 200px">
            </div>

            <div class="card">
                <div class="card-header"><?php echo e(__('Change Password')); ?></div>

                <div class="card-body">
                    <?php if($errors->any()): ?>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger col-12"><?php echo e($error); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger col-12"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success col-12"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(url('change-password')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="old_password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Old Password')); ?></label>

                            <div class="col-md-6">
                                <input id="old_password" type="password" class="form-control" name="old_password">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="new_password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('New Password')); ?></label>

                            <div class="col-md-6">
                                <input id="new_password" type="password" class="form-control" name="new_password">
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label for="re_password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirm New Password')); ?></label>

                            <div class="col-md-6">
                                <input id="re_password" type="password" class="form-control" name="confirm_password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-4"></div>
                            <div class="col-md-6">
                                <button type="submit" class="btn form-control"
                                    style="background-color: #63BA52; color: #fff; border-radius: 3px">
                                    <?php echo e(__('Change')); ?>

                                </button>
                            </div>
                            <div class="col-md-2"></div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/Auth/passwords/change-password.blade.php ENDPATH**/ ?>