<?php $__env->startSection('js-css'); ?>
    <style>
        .inline{
            display: inline;
        }
        .right{
            float: right;
        }
        .search-box{
            width: 30px;
            height: 30px;
            background: #979191;
            text-align: center;
        }
        .comment-wrap{
            width: 100%;
            height: 470px;
            overflow-y: scroll;
        }
        .bg{
            background: rgb(215, 241, 215);
        }
        .success{
            background:green;
        }
        .wrong{
            background: red;
        }
        .active-search-box{
            background: #dfb0f5;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br><br>


    <div class="container">
        <div class="row">

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="col-7">
                    <div class="card col-12">
                        <div class="card-body">
                            <div>
                                <?php if(isset($_GET['page'])): ?>
                                    Question <?php echo e($_GET['page']); ?> of <?php echo e($total_question); ?>

                                <?php endif; ?>
                            </div>
                            <div>
                                <?php if(!empty($item->mocques_ques->question_flag->where('user_id',Auth::user()->id)[0]) ): ?>
                                    <a href="<?php echo e(url('q-bank/drop/flag/'.$item->mocques_ques->question_flag->where('user_id',Auth::user()->id)[0]->id)); ?>" style="color:green"><i class="fa fa-star" aria-hidden="true"></i></a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('q-bank/add/flag/'.$item->mocques_ques->id)); ?>" color="green"><i class="fa fa-star" aria-hidden="true"></i></a>
                                <?php endif; ?>
                                <?php echo $item->question; ?>

                            </div>
                            <br><br>
                            <div class="card col-12">
                                <div class="card-body">

                                    
                                        <?php if($item->type == '0'): ?>
                                            <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($key == '0'): ?>
                                                    <?php if($key == $item->ans): ?>
                                                        <div class="success">
                                                            <span>A </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == $item->user_ans): ?>
                                                        <?php if('0' ==  $item->user_ans): ?>
                                                            <div class="wrong">
                                                                <span>A </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                                            </div>
                                                        <?php else: ?>
                                                            <div>
                                                                <span>A </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <div>
                                                            <span>A </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '1'): ?>
                                                    <?php if($key == $item->ans): ?>
                                                        <div class="success">
                                                            <span>B </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == $item->user_ans): ?>
                                                        <?php if(empty($item->user_ans)): ?>
                                                            <?php continue; ?>
                                                        <?php endif; ?>
                                                        <div class="wrong">
                                                            <span>B </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div>
                                                            <span>B </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '2'): ?>
                                                    <?php if($key == $item->ans): ?>
                                                        <div class="success">
                                                            <span>C </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == $item->user_ans): ?>
                                                        <?php if(empty($item->user_ans)): ?>
                                                            <?php continue; ?>
                                                        <?php endif; ?>
                                                        <div class="wrong">
                                                            <span>C </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div>
                                                            <span>C </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '3'): ?>
                                                    <?php if($key == $item->ans): ?>
                                                        <div class="success">
                                                            <span>D </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == $item->user_ans): ?>
                                                        <?php if(empty($item->user_ans)): ?>
                                                            <?php continue; ?>
                                                        <?php endif; ?>
                                                        <div class="wrong">
                                                            <span>D </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div>
                                                            <span>D </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '4'): ?>
                                                    <?php if($key == $item->ans): ?>
                                                        <div class="success">
                                                            <span>E </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == $item->user_ans): ?>
                                                        <?php if(empty($item->user_ans)): ?>
                                                            <?php continue; ?>
                                                        <?php endif; ?>
                                                        <div class="wrong">
                                                            <span>E </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div>
                                                            <span>E </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($item->ans == $item->user_ans): ?>
                                                <i class="fa fa-check" style="color:green" aria-hidden="true"></i>
                                            <?php else: ?>
                                                <i class="fa fa-times" style="color:red" aria-hidden="true"></i>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        
                                        <?php if($item->type == '1'): ?>
                                            <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($key == '0'): ?>
                                                        <div id="muli-ans<?php echo e($key); ?>">
                                                            <span>A  </span> <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '1'): ?>
                                                        <div id="muli-ans<?php echo e($key); ?>">
                                                            <span>B  </span> <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '2'): ?>
                                                        <div id="muli-ans<?php echo e($key); ?>">
                                                            <span>C  </span> <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '3'): ?>
                                                        <div id="muli-ans<?php echo e($key); ?>">
                                                            <span>D  </span> <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '4'): ?>
                                                        <div id="muli-ans<?php echo e($key); ?>">
                                                            <span>E  </span> <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $answers = explode('-',$item->ans);
                                            ?>
                                            <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <script>
                                                    document.querySelector('#muli-ans<?php echo e($answer); ?>').style.background = "green";
                                                </script>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <?php if($item->ans == $item->user_ans): ?>
                                                <i class="fa fa-check" style="color:green" aria-hidden="true"></i>
                                            <?php else: ?>
                                                <i class="fa fa-times" style="color:red" aria-hidden="true"></i>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        

                                </div>
                            </div>
                            <br>
                            <?php echo e($data->links()); ?>

                            <br><br>
                            <div>
                                <?php echo $item->explanation; ?>

                            </div>

                            <br><br><br>
                        </div>
                    </div>
                </div>


            
            <div class="col-5">
                <div class="card col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <?php for($i = 1; $i <= $total_question; $i++): ?>
                                    <?php if(isset($_GET['page'])): ?>
                                        <?php if($i == $_GET['page']): ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box ml-1 mb-1"><span><?php echo e($i); ?></span></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box ml-1 mb-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($i == '1'): ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box ml-1 mb-1"><span><?php echo e($i); ?></span></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box ml-1 mb-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                    <br><br><br>
                    <div class="card">
                        <div class="card-body">
                            <div class="comment-wrap">
                                <?php $__currentLoopData = $item->mocques_ques->question_comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12 bg mb-2 p-4">
                                        <h4>
                                            <?php echo e($value->name); ?>

                                            <?php if($value->user_id == Auth::user()->id): ?>
                                                <a href="<?php echo e(url('comment/'.$value->id)); ?>"><i class="fa fa-times" aria-hidden="true"></i></a>
                                            <?php endif; ?>
                                        </h4>
                                        <p><?php echo e($value->comment); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                    </div>
                    <?php if(Auth::user()->name): ?>
                        <form action="<?php echo e(url('comment/store')); ?>" method="post" class="mt-3">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="question_id" value="<?php echo e($item->mocques_ques->id); ?>">
                            <textarea name="comment" class="form-control" placeholder="Write Your Comment !!"></textarea>
                            <input type="submit" value="Submit" class="btn btn-success mt-3 mb-3 right" style="background: green">
                        </form>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







        </div>
    </div>



<br><br><br><br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Question_Bank\resources\views/frontend/mock-exam-result.blade.php ENDPATH**/ ?>