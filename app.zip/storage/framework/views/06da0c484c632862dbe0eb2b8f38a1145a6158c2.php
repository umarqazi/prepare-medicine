<?php $__env->startSection('content'); ?>

<br><br>


    <div class="container">

        <div class="col-sm-12 text-center text-left">
            <p class="text-left">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </p>
        </div>
        <br><br>
        <div class="row" style="float:right;">
            <div style="margin-right:5px;">
                <a href="<?php echo e(url('user/question/single/'.Auth::user()->id)); ?>" class="btn btn-spinner col-12 bg-info">View Single Question</a>
            </div>
            <div style="margin-left:5px;">
                <a href="<?php echo e(url('user/question/multi/'.Auth::user()->id)); ?>" class="btn btn-spinner col-12 bg-info">View Multichoice Question</a>
            </div>
        </div>
        <br><br><br>
        <div class="row">
            <div class="col-sm-6">
                <a href="<?php echo e(url('user/question/add/single')); ?>" class="btn btn-spinner col-12">Add Single Question</a>
            </div>
            <div class="col-sm-6">
                <a href="<?php echo e(url('user/question/add/multi')); ?>" class="btn btn-spinner col-12">Add Multichoice Question</a>
            </div>
        </div>
    </div>



<br><br><br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Question_Bank\resources\views/frontend/add-questions.blade.php ENDPATH**/ ?>