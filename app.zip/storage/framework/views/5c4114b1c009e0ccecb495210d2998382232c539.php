<?php $__env->startSection('content'); ?>

<br><br>
<div class="container">
    <h2>Recall Exam</h2>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis dolorem similique, illum ut expedita, error assumenda delectus nihil veritatis cupiditate commodi? Illo fugit odio molestiae officia dicta, nostrum modi reprehenderit sapiente aliquid facilis nemo incidunt autem dignissimos dolore quasi. Velit laborum officia quo distinctio magni aperiam incidunt voluptatem corporis, culpa corrupti. Eius ullam ratione aspernatur. Minima a officia nostrum numquam reiciendis mollitia unde perferendis ducimus. Cum consequuntur hic esse quas odit? Reprehenderit aspernatur velit ipsa modi, vitae officia error! Delectus beatae autem inventore minus provident, sed reprehenderit consequatur unde nemo quis natus dolor aspernatur tempora mollitia rerum velit minima corrupti accusantium asperiores non vel. Quis illo repudiandae quidem doloremque, rerum quo dolorum, sit id error obcaecati delectus, voluptate perferendis ab. Ratione quaerat beatae ut, debitis nostrum dicta sint delectus natus quasi illum voluptas maxime corrupti modi facere eaque quisquam sit temporibus culpa earum quam nulla. Deleniti sunt beatae vitae mollitia quidem, cumque eum fuga quam qui repellendus illo sequi dolores placeat eligendi in laboriosam officia explicabo rem nobis temporibus quibusdam. Expedita aliquam porro, asperiores iure nobis obcaecati, inventore, nulla cumque ipsum excepturi voluptates odit rem nisi accusamus illum. Itaque, mollitia! Nam modi, quidem at nihil beatae eaque minima perspiciatis reprehenderit.
    </p>
    <?php $__currentLoopData = $expired_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($key == '0'): ?>
            <a href="<?php echo e(url('q-bank/recall-exam/result/'.$item->id)); ?>" class="btn btn-info mr-1">March <?php echo e(date('Y')); ?><a>
        <?php elseif($key == '1'): ?>
            <a href="<?php echo e(url('q-bank/recall-exam/result/'.$item->id)); ?>" class="btn btn-info mr-1">June <?php echo e(date('Y')); ?></a>
        <?php elseif($key == '2'): ?>
            <a href="<?php echo e(url('q-bank/recall-exam/result/'.$item->id)); ?>" class="btn btn-info">November <?php echo e(date('Y')); ?></a>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($exists_data != '0'): ?>
        <?php $__currentLoopData = $continue_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(url('q-bank/recall-exam/'.$item->id)); ?>" class="btn btn-info">Continue Exam</a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <?php if(date('m') == '3'): ?>
            <a href="<?php echo e(url('q-bank/exam/recall-exam')); ?>" class="btn btn-info mr-1">Recall March <?php echo e(date('Y')); ?><a>
        <?php elseif(date('m') == '6'): ?>
            <a href="<?php echo e(url('q-bank/exam/recall-exam')); ?>" class="btn btn-info mr-1">Recall June <?php echo e(date('Y')); ?></a>
        <?php elseif(date('m') == '11'): ?>
            <a href="<?php echo e(url('q-bank/exam/recall-exam')); ?>" class="btn btn-info">Recall November <?php echo e(date('Y')); ?></a>
        <?php endif; ?>
    <?php endif; ?>
</div>
<br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Question_Bank\resources\views/frontend/recall-exam.blade.php ENDPATH**/ ?>