<?php $__env->startSection('js-css'); ?>
<style type="text/css">
    .existBTN{
        background-color: darkred !important;
        color: #fff !important;
        border: none !important;
        border-radius: 3px !important;
        padding: 3px 15px !important
    }
</style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>

<br>
<div class="container-fluid" style="padding-left: 30px; padding-right: 30px">
    <h2 style="font-size: 35px;text-align: center;">Manual Mock Exam</h2>
    <p class="text-justify">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis dolorem similique, illum ut expedita, error assumenda delectus nihil veritatis cupiditate commodi? Illo fugit odio molestiae officia dicta, nostrum modi reprehenderit sapiente aliquid facilis nemo incidunt autem dignissimos dolore quasi. Velit laborum officia quo distinctio magni aperiam incidunt voluptatem corporis, culpa corrupti. Eius ullam ratione aspernatur. Minima a officia nostrum numquam reiciendis mollitia unde perferendis ducimus. Cum consequuntur hic esse quas odit? Reprehenderit aspernatur velit ipsa modi, vitae officia error! Delectus beatae autem inventore minus provident, sed reprehenderit consequatur unde nemo quis natus dolor aspernatur tempora mollitia rerum velit minima corrupti accusantium asperiores non vel. Quis illo repudiandae quidem doloremque, rerum quo dolorum, sit id error obcaecati delectus, voluptate perferendis ab. Ratione quaerat beatae ut, debitis nostrum dicta sint delectus natus quasi illum voluptas maxime corrupti modi facere eaque quisquam sit temporibus culpa earum quam nulla. Deleniti sunt beatae vitae mollitia quidem, cumque eum fuga quam qui repellendus illo sequi dolores placeat eligendi in laboriosam officia explicabo rem nobis temporibus quibusdam. Expedita aliquam porro, asperiores iure nobis obcaecati, inventore, nulla cumque ipsum excepturi voluptates odit rem nisi accusamus illum. Itaque, mollitia! Nam modi, quidem at nihil beatae eaque minima perspiciatis reprehenderit.
    </p>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <?php $__currentLoopData = $expired_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($key%4 == '0'): ?>
                    <div class="col-md-3 col-sm-6 mb-2">
                        <a href="<?php echo e(url('q-bank/manual/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                            <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                            <span style="margin-top:17px">Mock <?php echo e($key+1); ?></span>
                        </a>
                    </div>
                <?php elseif($key%3 == '0'): ?>
                    <div class="col-md-3 col-sm-6 mb-2">
                        <a href="<?php echo e(url('q-bank/manual/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                            <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                            <span style="margin-top:17px">Mock <?php echo e($key+1); ?></span>
                        </a>
                    </div>
                <?php elseif($key%2 == '0'): ?>
                    <div class="col-md-3 col-sm-6 mb-2">
                        <a href="<?php echo e(url('q-bank/manual/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                            <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                            <span style="margin-top:17px">Mock <?php echo e($key+1); ?></span>
                        </a>
                    </div>
                <?php else: ?>
                    <div class="col-md-3 col-sm-6 mb-2">
                        <a href="<?php echo e(url('q-bank/manual/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                            <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                            <span style="margin-top:17px">Mock <?php echo e($key+1); ?></span>
                        </a>
                    </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    <?php if($exists_data != '0'): ?>
        <?php $__currentLoopData = $continue_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 col-sm-6 mb-2">
                <a href="<?php echo e(url('q-bank/manual/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden">
                    <img src="<?php echo e(url('storage/photos/mock/random-mock/continue-mock.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                    <span style="margin-top:17px"><?php echo e('Continue Mock'); ?></span>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="col-md-3 col-sm-6 mb-2">
            <button data-target="#exampleModalCenter" data-toggle="modal" type="button" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden">
                <img src="<?php echo e(url('storage/photos/mock/random-mock/new-mock.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                <span style="margin-top:17px"><?php echo e('New Mock'); ?></span>
            </button>
        </div>


        <!-- Modal -->
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle">Choose Specialties</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <ul class="nav nav-tabs md-tabs" id="myTabMD" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active" id="home-tab-md" data-toggle="tab" href="#home-md" role="tab" aria-controls="home-md" aria-selected="true">Specialities</a>
                        </li>
                    </ul>
                    <div class="tab-content card p-3" id="myTabContentMD">
                        <div class="tab-pane fade show active" id="home-md" role="tabpanel" aria-labelledby="home-tab-md">
                            
                            <form action="<?php echo e(url('q-bank/manual')); ?>" method="get">
                                <input type="hidden" value="cat" name="type">
                                <?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="custom-control custom-checkbox">
                                        <input type="checkbox" class="custom-control-input" id="cat<?php echo e($item->id); ?>" value="<?php echo e($item->id); ?>" name="search[]">
                                        <label class="custom-control-label" for="cat<?php echo e($item->id); ?>"><?php echo e($item->name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input type="submit" value="Continue" class="btn btn-success bg-success" style="float:right;border-radius: 4px">
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn existBTN" data-dismiss="modal">Exit</button>
                </div>
            </div>
            </div>
        </div>
    <?php endif; ?>
  </div> <!-- .row end here -->
</div>
<br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/frontend/manual-mock.blade.php ENDPATH**/ ?>