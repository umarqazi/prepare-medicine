<?php $__env->startSection('js-css'); ?>
    <style>
        .inline{
            display: inline;
        }
        .right{
            float: right;
        }
        .search-box{
            width: 30px;
            height: 30px;
            background: #979191;
            text-align: center;
        }
        .comment-wrap{
            width: 100%;
            height: 470px;
            overflow-y: scroll;
        }
        .bg{
            background: rgb(215, 241, 215);
        }
        .success{
            background:green;
        }
        .wrong{
            background: red;
        }
        .active-search-box{
            background: #dfb0f5;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br><br>


    <div class="container">
        <div class="row">

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="col-7">
                    <div class="card col-12">
                        <div class="card-body">
                            <div>
                                <?php if(isset($_GET['page'])): ?>
                                    Question <?php echo e($_GET['page']); ?> of <?php echo e($total_question); ?>

                                <?php endif; ?>
                            </div>
                            <div>
                                <?php if(!empty($item->mocques_ques->question_flag->where('user_id',Auth::user()->id)[0]) ): ?>
                                    <a href="<?php echo e(url('q-bank/drop/flag/'.$item->mocques_ques->question_flag->where('user_id',Auth::user()->id)[0]->id)); ?>" style="color:green"><i class="fa fa-star" aria-hidden="true"></i></a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('q-bank/add/flag/'.$item->mocques_ques->id)); ?>" color="green"><i class="fa fa-star" aria-hidden="true"></i></a>
                                <?php endif; ?>
                                <br>
                                <p style="color: #8a9591">Quistion Id <?php echo $item->mocques_ques->search_id; ?></p>
                                <a href="<?php echo e(url('lab-value')); ?>" target="_blank">Lab Value</a>
                                <br>
                                <?php echo $item->question; ?>

                            </div>
                            <br><br>
                            <div class="card col-12">
                                <div class="card-body">
                                    <?php if( empty($item->status) ): ?>
                                    
                                        <?php if($item->type == '0'): ?>
                                            <form action="<?php echo e(url('mock/compare/single')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="exam_id" value="<?php echo e($item->exam_id); ?>">
                                                <input type="hidden" name="question_id" value="<?php echo e($item->id); ?>">
                                                <input type="hidden" name="input_time" id="input_time" >
                                                <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($key == '0'): ?>
                                                        <span>A  </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                        <br>
                                                    <?php elseif($key == '1'): ?>
                                                        <span>B  </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                        <br>
                                                    <?php elseif($key == '2'): ?>
                                                        <span>C  </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                        <br>
                                                    <?php elseif($key == '3'): ?>
                                                        <span>D  </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                        <br>
                                                    <?php elseif($key == '4'): ?>
                                                        <span>E  </span> <input type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                        <br>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <input type="submit" value="Submit Answer" class="btn btn-primary right">
                                            </form>
                                        <?php endif; ?>

                                        
                                        <?php if($item->type == '1'): ?>
                                            <form action="<?php echo e(url('mock/compare/multi')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="exam_id" value="<?php echo e($item->exam_id); ?>">
                                                <input type="hidden" name="question_id" value="<?php echo e($item->id); ?>">
                                                <input type="hidden" name="input_time" id="input_time">
                                                <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($key == '0'): ?>
                                                        <span>A  </span> <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                        <br>
                                                    <?php elseif($key == '1'): ?>
                                                        <span>B  </span> <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                        <br>
                                                    <?php elseif($key == '2'): ?>
                                                        <span>C  </span> <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                        <br>
                                                    <?php elseif($key == '3'): ?>
                                                        <span>D  </span> <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                        <br>
                                                    <?php elseif($key == '4'): ?>
                                                        <span>E  </span> <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                        <br>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <input type="submit" value="Submit Answer" class="btn btn-primary right" style="background: green">
                                            </form>
                                        <?php endif; ?>
                                    
                                    <?php else: ?>
                                    
                                        <input type="hidden" id="input_time">
                                        <?php if($item->type == '0'): ?>
                                            <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($key == '0'): ?>
                                                    <?php if($key == $item->user_ans): ?>
                                                        <div>
                                                            <span>A </span> <input checked disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div>
                                                            <span>A </span> <input disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '1'): ?>
                                                    <?php if($key == $item->user_ans): ?>
                                                        <div>
                                                            <span>B </span> <input checked disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div>
                                                            <span>B </span> <input disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '2'): ?>
                                                    <?php if($key == $item->user_ans): ?>
                                                        <div>
                                                            <span>C </span> <input checked disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div>
                                                            <span>C </span> <input disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '3'): ?>
                                                    <?php if($key == $item->user_ans): ?>
                                                        <div>
                                                            <span>D </span> <input checked disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div>
                                                            <span>D </span> <input disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '4'): ?>
                                                    <?php if($key == $item->user_ans): ?>
                                                        <div>
                                                            <span>E </span> <input checked disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div>
                                                            <span>E </span> <input disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        
                                        <?php if($item->type == '1'): ?>
                                            <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($key == '0'): ?>
                                                    <div>
                                                        <span>A </span> <input disabled id="muli-ans<?php echo e($key); ?>" type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                    </div>
                                                <?php elseif($key == '1'): ?>
                                                    <div>
                                                        <span>B </span> <input disabled id="muli-ans<?php echo e($key); ?>" type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                    </div>
                                                <?php elseif($key == '2'): ?>
                                                    <div>
                                                        <span>C </span> <input disabled id="muli-ans<?php echo e($key); ?>" type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                    </div>
                                                <?php elseif($key == '3'): ?>
                                                    <div>
                                                        <span>D </span> <input disabled id="muli-ans<?php echo e($key); ?>" type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                    </div>
                                                <?php elseif($key == '4'): ?>
                                                    <div>
                                                        <span>E </span> <input disabled id="muli-ans<?php echo e($key); ?>" type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $answers = explode('-',$item->user_ans);
                                            ?>
                                            <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <script>
                                                    document.querySelector('#muli-ans<?php echo e($answer); ?>').checked = true;
                                                </script>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        
                                    <?php endif; ?>
                                </div>
                            </div>
                            <br>
                            <?php echo e($data->links()); ?><a href="<?php echo e(url('account/account-reset/'.$url)); ?>" class="btn btn-spinner bg-danger" style="float:right">Reset Account</a>
                            <br><br>
                            <div>
                                <button class="btn btn-info bg-info" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">
                                    Show Hint
                                </button>
                                <br><br>
                                <div class="collapse" id="collapseExample">
                                    <div class="card card-body">
                                        <?php if(!empty($item->hint) && $item->hint != null): ?>
                                            <?php echo $item->hint; ?>

                                        <?php else: ?>
                                            No hint defined !!
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <br><br><br>
                        </div>
                    </div>
                </div>


            
            <div class="col-5">
                <div class="card col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                               <div class="col-12">
                                    <div class="text-center" id="time"></div>
                               </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <?php for($i = 1; $i <= $total_question; $i++): ?>
                                    <?php if(isset($_GET['page'])): ?>
                                        <?php if($i == $_GET['page']): ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box active-search-box ml-1 mb-1"><span><?php echo e($i); ?></span></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box ml-1 mb-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if($i == '1'): ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box active-search-box ml-1 mb-1"><span><?php echo e($i); ?></span></a>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box ml-1 mb-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                    <br><br><br>
                    <div class="card">
                        <div class="card-body">
                            <a class="btn btn-info" href="<?php echo e(url('q-bank/mock/time/finish/'.Auth::user()->id.'/'.$id)); ?>">Finish Exam</a>
                            <a class="btn btn-info" href="<?php echo e(url('/')); ?>">Save and Exit</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







        </div>
    </div>



<br><br><br><br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function startTimer(duration, display) {
            var timer = duration, minutes, seconds;
            var Interval = setInterval(function () {
                hours = parseInt( timer/(60*60) );
                minutes = parseInt( (timer/60)%60 , 10);
                seconds = parseInt( timer % 60 , 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;

                display.textContent = hours + ':' + minutes + ":" + seconds;
                document.querySelector('#input_time').value = hours + ':' + minutes + ":" + seconds;

                if (seconds%5 == '0') {
                    // ajax request
                    var xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function() {
                        if (this.readyState == 4 && this.status == 200) {

                        }
                    };
                    xhttp.open("GET", "<?php echo e(url('q-bank/mock/time/'.Auth::user()->id.'/'.$id)); ?>"+"/"+hours +':' + minutes + ":" + seconds, true);
                    xhttp.send();
                }

                if (--timer < 0) {
                    alert('finished');
                    clearInterval(Interval);
                    // ajax request
                    var xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function() {
                        if (this.readyState == 4 && this.status == 200) {
                            window.location.href = "<?php echo e(url('q-bank/random/exam/result/'.$id)); ?>";
                        }
                    };
                    xhttp.open("GET", "<?php echo e(url('q-bank/mock/time/finish/'.Auth::user()->id.'/'.$id)); ?>", true);
                    xhttp.send();

                }

            }, 1000);
        }

        window.onload = function () {
            var fiveMinutes = <?php echo e($count_down); ?>,
                display = document.querySelector('#time');
            startTimer(fiveMinutes, display);
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Question_Bank\resources\views/frontend/mock-exam.blade.php ENDPATH**/ ?>