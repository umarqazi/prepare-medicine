<?php $__env->startSection('content'); ?>
    <br>
    <div class="container-fluid" style="padding-left: 30px; padding-right: 30px">
        <div class='page_banner_img_common'>
            <img src='/frontend/images/pages-banner.png' class='img-fluid'>
            <div class='overlay__'>
                <p>All About Plab </p>
            </div>
        </div>
        
        
        <?php echo $data; ?>


    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/plabone.preparemedicine.com/resources/views/frontend/about-plab-exam.blade.php ENDPATH**/ ?>