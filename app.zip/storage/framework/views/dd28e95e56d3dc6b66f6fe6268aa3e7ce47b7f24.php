<?php $__env->startSection('js-css'); ?>
<style type="text/css">
    .upgradeBTN{
        width: 100%;
        border: none;
        border-radius: 2px;
        padding: 10px;
        }
 </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<br>
    <div class="container">
        <div class="col-sm-12 text-center text-left">
            <h2 class="text-center" style="font-size: 35px">
                Reset My Account
            </h2>
            <br>
            <p class="text-justify">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </p>
        </div>
        <br><br>
        <div class="row text-center">
            <div class="col-md-3"></div>
            <div class="col-md-6 mb-2">
                <a onclick="return confirm('Are you sure?\nIt will clear your all activity record & progress!')" href="<?php echo e(url('account/account-reset/all')); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                    <img src="<?php echo e(url('storage/account/reset-gear.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                    <span style="margin-top:17px">RESET MY ACCOUNT</span>
                </a>
            </div>
            <div class="col-md-3"></div>
        </div>
    </div>


    <?php if(session()->has('error')): ?>
        <!-- Modal -->
        <div class="modal fade show" data-backdrop="static" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true" style="display: block; padding-right: 17px;">
          <div class="modal-dialog modal-dialog-centered " role="document">
            <div class="modal-content">
              <div class="modal-header" style="background: red">
                <h5 class="modal-title" id="exampleModalScrollableTitle"></h5>
                <button id="closeModal" type="button" class="close" data-dismiss="modal" aria-label="Close" style="color: #fff">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body text-center">
                <h5 style="color: red"><?php echo e(session()->get('error')); ?></h5>
                <br>
                <a href="<?php echo e(route('root_page')); ?>#most_popular_courses" class="upgradeBTN btn btn-success btn-sm">Upgrade Plan</a>
              </div>
              <div class="modal-footer">
              </div>
            </div>
          </div>
        </div>

        <script> 
            document.getElementById("closeModal").addEventListener("click", function(){ 
                let modalX = document.getElementById("exampleModalCenter");
                
                modalX.classList.remove("show");
                modalX.style.display = 'none';
            }); 
        </script>
    <?php endif; ?>

<br><br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/frontend/account-reset.blade.php ENDPATH**/ ?>