<?php $__env->startSection('js-css'); ?>
<script type="text/javascript">
    function FindNext () {
        var str = document.getElementById ("findInput").value;
        if (str == "") {
            alert ("Please enter some text to search!");
            return;
        }
        
        if (window.find) {        // Firefox, Google Chrome, Safari
            var found = window.find (str);
            if (!found) {
                alert ("The following text was not found:\n" + str);
            }
        }
        else {
            alert ("Your browser does not support this example!");
        }
    }
</script>
<style>
    /* Labels for checked inputs */
    input:checked + label {
        color: #0161C3;
    }
    /* checkbox && radio */
    .form-radio
    {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        display: inline-block;
        position: relative;
        background-color: #fff;
        color: #666;
        top: 10px;
        height: 30px;
        width: 30px;
        border: 0;
        border-radius: 0;
        cursor: pointer;     
        margin-right: 7px;
        outline: none;
    }
    .a::before{
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
        content: 'A';
    }
    .b::before{
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
        content: 'B';
    }
    .c::before{
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
        content: 'C';
    }
    .d::before{
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
        content: 'D';
    }
    .e::before{
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
        content: 'E';
    }
    .form-radio:checked::before
    {
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
    }
    .form-radio:hover
    {
        background-color: #f7f7f7;
    }
    .form-radio:checked
    {
        background-color: #f1f1f1;
    }
    label
    {
        font: 15px/1.7 'Open Sans', sans-serif;
        color: #333;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        cursor: pointer;
    } 
</style>
<style>
    body{
        background: #F4F1EC;
    }
    .inline{
        display: inline;
    }
    .right{
        float: right;
    }
    .search-box{
        background: #ffffff;
        width: 40px; 
        height: 40px; 
        padding: 6px 0px; 
        border-radius: 20px; 
        text-align: center;
    }
    .comment-wrap{
        width: 100%;
        height: 220px;
        overflow-y: scroll;
    }
    .bg{
        background: #F4F1EC;
    }
    .success{
        background: #C2F7CF;
    }
    .wrong{
        background: #F9C1C6;
    }
    .active-search-box{
        background: #fff;
        -webkit-box-shadow: 0px 0px 15px 3px rgba(0,0,0,0.75);
        -moz-box-shadow: 0px 0px 15px 3px rgba(0,0,0,0.75);
        box-shadow: 0px 0px 15px 3px rgba(0,0,0,0.75);
    }
    .center{
        margin:0 auto;
        margin-top: 15px;
        margin-bottom: 15px;
        /* background: #DBDBDB; */
    }
    .cart-tab{
        margin:2.5%;
    }
    .radius{
        border-radius: 5%;
    }
</style>
<style>
    /* chart style */
    .horizontal .progress-bar {
    float: left;
    height: 45px;
    width: 100%;
    padding: 12px 0;
    }

    .horizontal .progress-track {
    position: relative;
    width: 100%;
    height: 20px;
    background: #ebebeb;
    }

    .horizontal .progress-fill {
    position: relative;
    background: #666;
    height: 20px;
    width: 50%;
    color: #fff;
    text-align: center;
    font-family: "Lato","Verdana",sans-serif;
    font-size: 12px;
    line-height: 20px;
    }

    .rounded .progress-track,
    .rounded .progress-fill {
    border-radius: 3px;
    box-shadow: inset 0 0 5px rgba(0,0,0,.2);
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br><br>


    <div class="container">
        <div class="row">

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <div class="col-md-3" id="pc">
                    <div class="center col-12">
                        <div class="row">
                            <div class="col-12">
                                <div class="text-center" id="time"></div>
                            </div>
                        </div>
                        <div class="row">
                            <?php for($i = 1; $i <= $total_question; $i++): ?>
                                <?php if(isset($_GET['page'])): ?>
                                    <?php if($i == $_GET['page']): ?>
                                        <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($i == '1'): ?>
                                        <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box ml-1 mb-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <br>
                </div>

                
                <div class="col-md-9">
                    <div class="col-12">
                        
                            <div>
                                <?php if(isset($_GET['page'])): ?>
                                    Question <?php echo e($_GET['page']); ?> of <?php echo e($total_question); ?>

                                <?php endif; ?>
                                <?php if(!empty($item->mocques_ques->question_flag->where('user_id',Auth::user()->id)[0]) ): ?>
                                    <a href="<?php echo e(url('q-bank/drop/flag/'.$item->mocques_ques->question_flag->where('user_id',Auth::user()->id)[0]->id)); ?>" style="color:green;font-size: 18px;"><i class="fa fa-bookmark" aria-hidden="true"></i></a>
                                <?php else: ?>
                                    <a href="<?php echo e(url('q-bank/add/flag/'.$item->mocques_ques->id)); ?>" style="font-size: 18px;"><i class="fa fa-bookmark" aria-hidden="true"></i></a>
                                <?php endif; ?>
                                <br>
                                <div>
                                    <p style="color: #8a9591;background:#81DB97;display:inline-block;padding:0 8px;">Question Id : <?php echo e($item->search_id); ?></p>
                                    <p style="display:inline-block;" class="mr-1">
                                        <a style="background:#81DB97;display:inline-block;padding:0 15px;" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">Hint</a>
                                    </p>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius:10px">Lab Values</button>
                                </div>
                                <div class="collapse" id="collapseExample">
                                    <?php if(!empty($item->hint) && $item->hint != null): ?>
                                        <?php echo $item->hint; ?>

                                    <?php else: ?>
                                        No hint defined !!
                                    <?php endif; ?>
                                </div>
                                <?php echo $item->question; ?>


                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-xl" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLabel">Lab Values</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-group col-12">
                                                    <input type="text" class="form-control" id="findInput" placeholder="find your information...">
                                                </div>
                                                <button type="submit" class="btn btn-info col-12" onclick="FindNext ();">find</button>
                                                <br>
                                                <div id="hint">
                                                    <?php echo $lab; ?>

                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br><br>
                            </div>
                            <div class="col-12">
                               
                                    <?php if( empty($item->status) ): ?>
                                    
                                        <?php if($item->type == '0'): ?>
                                            <form action="<?php echo e(url('mock/compare/single')); ?>" method="post">
                                                <?php if( $data->hasMorePages() ): ?>
                                                    <input type="hidden" name="page" value="<?php echo e($data->nextPageUrl()); ?>">
                                                <?php else: ?>
                                                    <input type="hidden" name="page" value="0">    
                                                <?php endif; ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="exam_id" value="<?php echo e($item->exam_id); ?>">
                                                <input type="hidden" name="question_id" value="<?php echo e($item->id); ?>">
                                                <input type="hidden" name="input_time" id="input_time" >
                                                <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($key == '0'): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio a" id="radio-10"><label for="radio-10" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '1'): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio b" id="radio-11"><label for="radio-11" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '2'): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio c" id="radio-12"><label for="radio-12" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '3'): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio d" id="radio-13"><label for="radio-13" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '4'): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio e" id="radio-14"><label for="radio-14" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data->hasPages()): ?>
                                                    <table style="margin:0 auto">
                                                        <tr>
                                                            
                                                            <?php if($data->onFirstPage()): ?>
                                                                <td> <i class="fa fa-arrow-circle-left disabled" style="font-size:36px"></i> </td>
                                                            <?php else: ?>
                                                                    <td> <a href="<?php echo e($data->previousPageUrl()); ?>"><i class="fa fa-arrow-circle-left" style="font-size:36px;color:#63BA52"></i></a> </td>
                                                            <?php endif; ?>
                                                            
                                                            <td> <input type="submit" value="Submit Answer" class="btn btn-primary ml-4 mr-4" style="background: #0161C3;border-radius:10px"> </td>
                                                            
                                                            <?php if($data->hasMorePages()): ?>
                                                                    <td> <a href="<?php echo e($data->nextPageUrl()); ?>" ><i class="fa fa-arrow-circle-right" style="font-size:36px;color:#63BA52"></i></a> </td>
                                                            <?php else: ?>
                                                                    <td> <i class="fa fa-arrow-circle-right disabled" style="font-size:36px"></i> </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                    </table>
                                                <?php endif; ?>
                                            </form>
                                        <?php endif; ?>

                                        
                                        <?php if($item->type == '1'): ?>
                                            <form action="<?php echo e(url('mock/compare/multi')); ?>" method="post">
                                                <?php if( $data->hasMorePages() ): ?>
                                                    <input type="hidden" name="page" value="<?php echo e($data->nextPageUrl()); ?>">
                                                <?php else: ?>
                                                    <input type="hidden" name="page" value="0">    
                                                <?php endif; ?>
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="exam_id" value="<?php echo e($item->exam_id); ?>">
                                                <input type="hidden" name="question_id" value="<?php echo e($item->id); ?>">
                                                <input type="hidden" name="input_time" id="input_time">
                                                <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($key == '0'): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio a" id="radio-15"><label for="radio-15" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '1'): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio b" id="radio-16"><label for="radio-16" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '2'): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio c" id="radio-17"><label for="radio-17" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '3'): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio d" id="radio-18"><label for="radio-18" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php elseif($key == '4'): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio e" id="radio-19"><label for="radio-19" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data->hasPages()): ?>
                                                    <table style="margin:0 auto">
                                                        <tr>
                                                            
                                                            <?php if($data->onFirstPage()): ?>
                                                                <td> <i class="fa fa-arrow-circle-left disabled" style="font-size:36px"></i> </td>
                                                            <?php else: ?>
                                                                    <td> <a href="<?php echo e($data->previousPageUrl()); ?>"><i class="fa fa-arrow-circle-left" style="font-size:36px;color:#63BA52"></i></a> </td>
                                                            <?php endif; ?>
                                                            
                                                            <td> <input type="submit" value="Submit Answer" class="btn btn-primary ml-4 mr-4" style="background: #0161C3;border-radius:10px"> </td>
                                                            
                                                            <?php if($data->hasMorePages()): ?>
                                                                    <td> <a href="<?php echo e($data->nextPageUrl()); ?>" ><i class="fa fa-arrow-circle-right" style="font-size:36px;color:#63BA52"></i></a> </td>
                                                            <?php else: ?>
                                                                    <td> <i class="fa fa-arrow-circle-right disabled" style="font-size:36px"></i> </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                    </table>
                                                <?php endif; ?>
                                            </form>
                                        <?php endif; ?>
                                    
                                    <?php else: ?>
                                    
                                        <input type="hidden" id="input_time">
                                        <?php if($item->type == '0'): ?>
                                            <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($key == '0'): ?>
                                                    <?php if($key == $item->user_ans): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input checked disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio a" id="radio-1"><label for="radio-1" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio a" id="radio-11"><label for="radio-11" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '1'): ?>
                                                    <?php if($key == $item->user_ans): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input checked disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio b" id="radio-12"><label for="radio-12" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio b" id="radio-13"><label for="radio-13" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '2'): ?>
                                                    <?php if($key == $item->user_ans): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input checked disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio c" id="radio-14"><label for="radio-14" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio c" id="radio-15"><label for="radio-15" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '3'): ?>
                                                    <?php if($key == $item->user_ans): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input checked disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio d" id="radio-16"><label for="radio-16" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio d" id="radio-17"><label for="radio-17" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php elseif($key == '4'): ?>
                                                    <?php if($key == $item->user_ans): ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input checked disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio e" id="radio-18"><label for="radio-18" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="mb-2 pb-2 radius">
                                                            <input disabled type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio e" id="radio-19"><label for="radio-19" class="inline">
                                                            <p class="inline"><?php echo e($value->ans); ?></p>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data->hasPages()): ?>
                                                <table style="margin:0 auto">
                                                    <tr>
                                                        
                                                        <?php if($data->onFirstPage()): ?>
                                                            <td> <i class="fa fa-arrow-circle-left disabled" style="font-size:36px"></i> </td>
                                                        <?php else: ?>
                                                                <td> <a href="<?php echo e($data->previousPageUrl()); ?>"><i class="fa fa-arrow-circle-left" style="font-size:36px;color:#63BA52"></i></a> </td>
                                                        <?php endif; ?>
                                                        
                                                        <?php if($data->hasMorePages()): ?>
                                                                <td> <a href="<?php echo e($data->nextPageUrl()); ?>" ><i class="fa fa-arrow-circle-right ml-5" style="font-size:36px;color:#63BA52"></i></a> </td>
                                                        <?php else: ?>
                                                                <td> <i class="fa fa-arrow-circle-right disabled ml-5" style="font-size:36px"></i> </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                </table>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        
                                        <?php if($item->type == '1'): ?>
                                            <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($key == '0'): ?>
                                                    <div class="mb-2 pb-2 radius">
                                                        <input disabled id="muli-ans<?php echo e($key); ?>" type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio a"><label for="muli-ans<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                    </div>
                                                <?php elseif($key == '1'): ?>
                                                    <div class="mb-2 pb-2 radius">
                                                        <input disabled id="muli-ans<?php echo e($key); ?>" type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio b"><label for="muli-ans<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                    </div>
                                                <?php elseif($key == '2'): ?>
                                                    <div class="mb-2 pb-2 radius">
                                                        <input disabled id="muli-ans<?php echo e($key); ?>" type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio c"><label for="muli-ans<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                    </div>
                                                <?php elseif($key == '3'): ?>
                                                    <div class="mb-2 pb-2 radius">
                                                        <input disabled id="muli-ans<?php echo e($key); ?>" type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio d"><label for="muli-ans<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                    </div>
                                                <?php elseif($key == '4'): ?>
                                                    <div class="mb-2 pb-2 radius">
                                                        <input disabled id="muli-ans<?php echo e($key); ?>" type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio e"><label for="muli-ans<?php echo e($key); ?>" class="inline">
                                                        <p class="inline"><?php echo e($value->ans); ?></p>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $answers = explode('-',$item->user_ans);
                                            ?>
                                            <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <script>
                                                    document.querySelector('#muli-ans<?php echo e($answer); ?>').checked = true;
                                                </script>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($data->hasPages()): ?>
                                                <table style="margin:0 auto">
                                                    <tr>
                                                        
                                                        <?php if($data->onFirstPage()): ?>
                                                            <td> <i class="fa fa-arrow-circle-left disabled" style="font-size:36px"></i> </td>
                                                        <?php else: ?>
                                                                <td> <a href="<?php echo e($data->previousPageUrl()); ?>"><i class="fa fa-arrow-circle-left" style="font-size:36px;color:#63BA52"></i></a> </td>
                                                        <?php endif; ?>
                                                        
                                                        <?php if($data->hasMorePages()): ?>
                                                                <td> <a href="<?php echo e($data->nextPageUrl()); ?>" ><i class="fa fa-arrow-circle-right ml-5" style="font-size:36px;color:#63BA52"></i></a> </td>
                                                        <?php else: ?>
                                                                <td> <i class="fa fa-arrow-circle-right disabled ml-5" style="font-size:36px"></i> </td>
                                                        <?php endif; ?>
                                                    </tr>
                                                </table>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        
                                    <?php endif; ?>
                        
                            </div>
                            <br><br>
                            <table style="margin:0 auto">
                                <tr>
                                    <td>
                                        <a class="btn btn-info mr-5 bg-danger" href="<?php echo e(url('q-bank/mock/time/finish/'.Auth::user()->id.'/'.$id)); ?>" style="padding-left:40px;padding-right:40px;border-radius:10px">Finish</a>
                                    </td>
                                    <td>
                                        <a class="btn btn-info bg-info" href="<?php echo e(url('/')); ?>" style="padding-left:40px;padding-right:40px;border-radius:10px;">Save and Exit</a>
                                    </td>
                                </tr>
                            </table>
                            <br><br><br>
                    </div>
                </div>

                
                <div class="col-md-3" id="mobile">
                    <div class="center col-12">
                        <div class="row">
                            <div class="col-12">
                                <div class="text-center" id="time"></div>
                            </div>
                        </div>
                        <div class="row">
                            <?php for($i = 1; $i <= $total_question; $i++): ?>
                                <?php if(isset($_GET['page'])): ?>
                                    <?php if($i == $_GET['page']): ?>
                                        <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($i == '1'): ?>
                                        <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('q-bank/random/exam/'.$id.'?page='.$i)); ?>" class="search-box ml-1 mb-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <br>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>



<br><br><br><br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        function startTimer(duration, display) {
            var timer = duration, minutes, seconds;
            var Interval = setInterval(function () {
                hours = parseInt( timer/(60*60) );
                minutes = parseInt( (timer/60)%60 , 10);
                seconds = parseInt( timer % 60 , 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;

                display.textContent = hours + ':' + minutes + ":" + seconds;
                document.querySelector('#input_time').value = hours + ':' + minutes + ":" + seconds;

                if (seconds%5 == '0') {
                    // ajax request
                    var xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function() {
                        if (this.readyState == 4 && this.status == 200) {

                        }
                    };
                    xhttp.open("GET", "<?php echo e(url('q-bank/mock/time/'.Auth::user()->id.'/'.$id)); ?>"+"/"+hours +':' + minutes + ":" + seconds, true);
                    xhttp.send();
                }

                if (--timer < 0) {
                    alert('finished');
                    clearInterval(Interval);
                    // ajax request
                    var xhttp = new XMLHttpRequest();
                    xhttp.onreadystatechange = function() {
                        if (this.readyState == 4 && this.status == 200) {
                            window.location.href = "<?php echo e(url('q-bank/random/exam/result/'.$id)); ?>";
                        }
                    };
                    xhttp.open("GET", "<?php echo e(url('q-bank/mock/time/finish/'.Auth::user()->id.'/'.$id)); ?>", true);
                    xhttp.send();

                }

            }, 1000);
        }

        window.onload = function () {
            var fiveMinutes = <?php echo e($count_down); ?>,
            display = document.querySelector('#time');
            startTimer(fiveMinutes, display);
        };
    </script>
    <script>
        // chart js
        $('.horizontal .progress-fill span').each(function(){
            var percent = $(this).html();
            $(this).parent().css('width', percent);
        });


        $('.vertical .progress-fill span').each(function(){
            var percent = $(this).html();
            var pTop = 100 - ( percent.slice(0, percent.length - 1) ) + "%";
            $(this).parent().css({
                'height' : percent,
                'top' : pTop
            });
        });
    </script>
    <script>
        window.addEventListener("resize", responsive);

        function responsive() {
            if(screen.width > 767){
                document.getElementById("mobile").style.display = "none";
                document.getElementById("pc").style.display = "block";
            }else{
                document.getElementById("pc").style.display = "none";
                document.getElementById("mobile").style.display = "block";
            }
        }
        
        if(screen.width > 767){
            document.getElementById("mobile").style.display = "none";
            document.getElementById("pc").style.display = "block";
        }else{
            document.getElementById("pc").style.display = "none";
            document.getElementById("mobile").style.display = "block";
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project emon vai\question_bank\resources\views/frontend/mock-exam.blade.php ENDPATH**/ ?>