<?php $__env->startSection('content'); ?>
    <!-- Hero Slider start -->
    <div class="hero-slider">

        <div class="hero-slider-active owl-carousel">

            <div class="singleSlide" data-black-overlay="3">
                <div class="itemBg">
                    <img src="<?php echo e(url('frontend/images/slider/background-image-1.jpg')); ?>" alt="">
                </div>
                <!-- Hero Content One Start -->
                <div class="container">
                    <div class="hero-content-one">
                        <div class="row">
                            <div class="col">
                                <div class="slider-text-info">
                                    <h1><span>Fast Revision </span> <br> For PLAB ONE</h1>
                                    <a href="about.html" class="btn slider-btn uppercase"><span>PLAB ONE</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Hero Content One End -->
            </div>

            <div class="singleSlide" data-black-overlay="3">
                <div class="itemBg">
                    <img src="<?php echo e(url('frontend/images/slider/background-image-2.jpg')); ?>" alt="">
                </div>
                <!-- Hero Content One Start -->
                <div class="container">
                    <div class="hero-content-one">
                        <div class="row">
                            <div class="col">
                                <div class="slider-text-info">
                                    <h1><span>Fast Revision </span> <br> For PLAB ONE </h1>
                                    <a href="about.html" class="btn slider-btn uppercase"><span>PLAB ONE</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Hero Content One End -->
            </div>

            <div class="singleSlide" data-black-overlay="3">
                <div class="itemBg">
                    <img src="<?php echo e(url('frontend/images/slider/background-image-3.jpg')); ?>" alt="">
                </div>
                <!-- Hero Content One Start -->
                <div class="container">
                    <div class="hero-content-one">
                        <div class="row">
                            <div class="col">
                                <div class="slider-text-info">
                                    <h1><span>Fast Revision </span> <br> For PLAB ONE </h1>
                                    <a href="about.html" class="btn slider-btn uppercase"><span>PLAB ONE</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Hero Content One End -->
            </div>

        </div>
    </div>
    <!-- Hero Slider end -->

    <!-- Our Course Categories Area -->
    <div class="our-course-categories-area section-ptb">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 ml-auto mr-auto">
                    <!-- section-title -->
                    <div class="section-title-three">
                        <h4>WELCOME TO PREPARE MEDICINE</h4>
                        <h3>OUR SUBSCRIPTION PLANS</h3>
                        <p>We have several subscription plans to meet all budgets. These are outlined on the table below, and you will see
                            that our plans suit all budgets. One unique element of our service is supporting displaced medical staff who are
                            registered as such through the BMA RDI (refugee doctors’ initiative), REACHE North West or any similar
                            initiative in the UK. When you register with us, you will be asked about eligibility for this service. Our philosophy
                            in this respect is very much akin to what Helen Keller reminded us: While they were saying among themselves it
                            cannot be done, it was done. You have faced obstacles, but we will help you to make it happen. </p>
                    </div><!--// section-title -->
                </div>
            </div>


            <div class="row">
                <div class="col">
                    <div class="course-categories-wrap">
                        <div class="coustom-col-2">
                            <!-- single-course-categories -->
                            <div class="single-course-categories malachite">
                                <div class="item-inner">
                                    <div class="cours-icon">
                                        <img src="<?php echo e(url('frontend/images/icon/trail.png')); ?>" alt="">
                                    </div>
                                    <div class="cours-title">
                                        <h5>Trial</h5>
                                    </div>
                                </div>
                            </div><!--// single-course-categories -->
                        </div>

                        <div class="coustom-col-2">
                            <!-- single-course-categories -->
                            <div class="single-course-categories sunglow">
                                <div class="item-inner">
                                    <div class="cours-icon">
                                        <img src="<?php echo e(url('frontend/images/icon/refugee.png')); ?>" alt="">
                                    </div>
                                    <div class="cours-title">
                                        <h5>Refugees Doctors</h5>
                                    </div>
                                </div>
                            </div><!--// single-course-categories -->
                        </div>

                        <div class="coustom-col-2">
                            <!-- single-course-categories -->
                            <div class="single-course-categories mariner">
                                <div class="item-inner">
                                    <div class="cours-icon">
                                        <img src="<?php echo e(url('frontend/images/icon/basic.png')); ?>" alt="">
                                    </div>
                                    <div class="cours-title">
                                        <h5>Basic</h5>
                                    </div>
                                </div>
                            </div><!--// single-course-categories -->
                        </div>

                        <div class="coustom-col-2">
                            <!-- single-course-categories -->
                            <div class="single-course-categories brilliantrose">
                                <div class="item-inner">
                                    <div class="cours-icon">
                                        <img src="<?php echo e(url('frontend/images/icon/standard.png')); ?>" alt="">
                                    </div>
                                    <div class="cours-title">
                                        <h5>Standard</h5>
                                    </div>
                                </div>
                            </div><!--// single-course-categories -->
                        </div>

                        <div class="coustom-col-2">
                            <!-- single-course-categories -->
                            <div class="single-course-categories shakespeare">
                                <div class="item-inner">
                                    <div class="cours-icon">
                                        <img src="<?php echo e(url('frontend/images/icon/advance.png')); ?>" alt="">
                                    </div>
                                    <div class="cours-title">
                                        <h5>Advance</h5>
                                    </div>
                                </div>
                            </div><!--// single-course-categories -->
                        </div>

                        <div class="coustom-col-2">
                            <!-- single-course-categories -->
                            <div class="single-course-categories deyork">
                                <div class="item-inner">
                                    <div class="cours-icon">
                                        <img src="<?php echo e(url('frontend/images/icon/professiona.png')); ?>" alt="">
                                    </div>
                                    <div class="cours-title">
                                        <h5>Professional</h5>
                                    </div>
                                </div>
                            </div><!--// single-course-categories -->
                        </div>

                        <div class="all-course-btn">
                            <a href="<?php echo e(route('subscription_plans', 'plab-one')); ?>" class="all-course">subscriptions</a>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
    <!--// Our Course Categories Area -->

    <!-- Why should Education Area -->
    <div class="should-education-area section-ptb-160 should-bg" data-black-overlay="6">
        <div class="container">
            <div class="row">
                <div class="col-lg-8  ml-auto mr-auto">
                    <div class="section-title">
                        <h4>WHY PREPARE MEDICINE</h4>
                        <h3 class="text-white">Why should We</h3>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-4 col-md-6 col-12">
                    <!-- single-choose-service -->
                    <div class="single-choose-service text-center mt--30">
                        <div class="service-icon">
                            <img src="<?php echo e(url('frontend/images/icon/choos-01.png')); ?>" alt="">
                        </div>
                        <div class="service-content">
                            <h4>Online Revision</h4>
                            <p>Contrary to popular belief, Lorem
                                Ipsum isnotimply random text. It has roots in a pi
                                classiLatin litture from 45 BC,</p>
                        </div>
                    </div><!--// single-choose-service -->
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <!-- single-choose-service -->
                    <div class="single-choose-service text-center mt--30">
                        <div class="service-icon">
                            <img src="<?php echo e(url('frontend/images/icon/support.png')); ?>" alt="">
                        </div>
                        <div class="service-content">
                            <h4>Refugees Support</h4>
                            <p>Contrary to popular belief, Lorem
                                Ipsum isnotimply random text. It has roots in a pi
                                classiLatin litture from 45 BC,</p>
                        </div>
                    </div><!--// single-choose-service -->
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <!-- single-choose-service -->
                    <div class="single-choose-service text-center mt--30">
                        <div class="service-icon">
                            <img src="<?php echo e(url('frontend/images/icon/choos-03.png')); ?>" alt="">
                        </div>
                        <div class="service-content">
                            <h4>Authentication</h4>
                            <p>Contrary to popular belief, Lorem
                                Ipsum isnotimply random text. It has roots in a pi
                                classiLatin litture from 45 BC,</p>
                        </div>
                    </div><!--// single-choose-service -->
                </div>
            </div>
        </div>
    </div>
    <!--// Why should Education Area -->

    <!-- Most Popular Courses Area -->
    <div id="most_popular_courses" class="most-popular-courses-area section-ptb">
        <div class="container">
            <div class="row">
                <div class="col-lg-8  ml-auto mr-auto">
                    <div class="section-title-two">
                        <h4>why choose us</h4>
                        <h3>Most Popular Courses</h3>
                    </div>
                </div>
            </div>

            <div class="row">

                <div class="col-lg-4 col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-popular-courses mt--30">
                        <div class="popular-courses-image">
                            <a href="#"><img src="<?php echo e(url('frontend/images/courses/courses-01.jpg')); ?>" alt=""></a>
                        </div>
                        <div class="popular-courses-contnet">
                            <h5>PLAB ONE</h5>
                            <div class="post_meta">
                                <ul>
                                    <li><a href="#">PLAB ONE</a></li>
                                    <li><p>Duration : 4 Yr</p></li>
                                </ul>
                            </div>
                            <p>Contrary to popular belief, Lorem Ipsum isnotimply random text..</p>
                            <div class="button-block">
                                <a href="<?php echo e(route('subscription_plans', 'plab-one')); ?>" class="botton-border">SUBSCRIBE</a>
                            </div>
                        </div>
                    </div><!--// single-courses -->
                </div>

                <div class="col-lg-4 col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-popular-courses mt--30">
                        <div class="popular-courses-image">
                            <a href="#"><img src="<?php echo e(url('frontend/images/courses/courses-02.jpg')); ?>" alt=""></a>
                        </div>
                        <div class="popular-courses-contnet">
                            <h5>MRCP ONE</h5>
                            <div class="post_meta">
                                <ul>
                                    <li><a href="#">MRCP ONE</a></li>
                                    <li><p>Duration : 4 Yr</p></li>
                                </ul>
                            </div>
                            <p>Contrary to popular belief, Lorem Ipsum isnotimply random text..</p>
                            <div class="button-block">
                                <a href="<?php echo e(route('subscription_plans', 'mrcp-one')); ?>" class="botton-border">SUBSCRIBE</a>
                            </div>
                        </div>
                    </div><!--// single-courses -->
                </div>

                <div class="col-lg-4 col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-popular-courses mt--30">
                        <div class="popular-courses-image">
                            <a href="#"><img src="<?php echo e(url('frontend/images/courses/courses-03.jpg')); ?>" alt=""></a>
                        </div>
                        <div class="popular-courses-contnet">
                            <h5>FRCEM Primary</h5>
                            <div class="post_meta">
                                <ul>
                                    <li><a href="#">FRCEM Primary</a></li>
                                    <li><p>Duration : 4 Yr</p></li>
                                </ul>
                            </div>
                            <p>Contrary to popular belief, Lorem Ipsum isnotimply random text..</p>
                            <div class="button-block">
                                <a href="<?php echo e(route('subscription_plans', 'frcem-primary')); ?>" class="botton-border">SUBSCRIBE</a>
                            </div>
                        </div>
                    </div><!--// single-courses -->
                </div>

                <div class="col-lg-4 col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-popular-courses mt--30">
                        <div class="popular-courses-image">
                            <a href="#"><img src="<?php echo e(url('frontend/images/courses/courses-04.jpg')); ?>" alt=""></a>
                        </div>
                        <div class="popular-courses-contnet">
                            <h5>USMLE ONE</h5>
                            <div class="post_meta">
                                <ul>
                                    <li><a href="#">USMLE ONE</a></li>
                                    <li><p>Duration : 4 Yr</p></li>
                                </ul>
                            </div>
                            <p>Contrary to popular belief, Lorem Ipsum isnotimply random text..</p>
                            <div class="button-block">
                                <a href="<?php echo e(route('subscription_plans', 'usmle-one')); ?>" class="botton-border">SUBSCRIBE</a>
                            </div>
                        </div>
                    </div><!--// single-courses -->
                </div>

                <div class="col-lg-4 col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-popular-courses mt--30">
                        <div class="popular-courses-image">
                            <a href="#"><img src="<?php echo e(url('frontend/images/courses/courses-05.jpg')); ?>" alt=""></a>
                        </div>
                        <div class="popular-courses-contnet">
                            <h5>AMC</h5>
                            <div class="post_meta">
                                <ul>
                                    <li><a href="#">AMC</a></li>
                                    <li><p>Duration : 4 Yr</p></li>
                                </ul>
                            </div>
                            <p>Contrary to popular belief, Lorem Ipsum isnotimply random text..</p>
                            <div class="button-block">
                                <a href="<?php echo e(route('subscription_plans', 'amc')); ?>" class="botton-border">SUBSCRIBE</a>
                            </div>
                        </div>
                    </div><!--// single-courses -->
                </div>

                <div class="col-lg-4 col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-popular-courses mt--30">
                        <div class="popular-courses-image">
                            <a href="#"><img src="<?php echo e(url('frontend/images/courses/courses-06.jpg')); ?>" alt=""></a>
                        </div>
                        <div class="popular-courses-contnet">
                            <h5>UKMLE</h5>
                            <div class="post_meta">
                                <ul>
                                    <li><a href="#">UKMLE</a></li>
                                    <li><p>Duration : 4 Yr</p></li>
                                </ul>
                            </div>
                            <p>Contrary to popular belief, Lorem Ipsum isnotimply random text..</p>
                            <div class="button-block">
                                <a href="<?php echo e(route('subscription_plans', 'ukmle')); ?>" class="botton-border">SUBSCRIBE</a>
                            </div>
                        </div>
                    </div><!--// single-courses -->
                </div>

            </div>

        </div>
    </div>
    <!--// Most Popular Courses Area -->

    <!-- Free Introductory Seminar -->
    <div class="free-introductory-area section-ptb-160 free-introductory-bg" data-black-overlay="6">
        <div class="container">
            <div class="row">
                <div class="col-lg-8  ml-auto mr-auto">
                    <div class="section-title-three mt--30 mb--30">
                        <h4>How to Get Your Dream Work?</h4>
                        <h3 class="text-white">FREE TRIAL</h3>
                        <p class="text-white">Contrary to popular belief, Lorem Ipsum is not simply random text.
                         It has roots in a pi classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock,</p>
                        <div class="free-introductory-btn">
                            <a href="<?php echo e(route('subscription_plans', 'plab-one')); ?>" class="introductory-btn">FREE TRIAL</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// Free Introductory Seminar -->

    <!-- Our Blog Area -->
    <div class="our-blog-area section-ptb">
        <div class="container">
            <div class="col-lg-8  ml-auto mr-auto">
                <!-- section-title -->
                <div class="section-title-two">
                    <h4>OUR NOTES</h4>
                    <h3>SUPER FAST REVISION</h3>
                </div><!--// section-title -->
            </div>
            <div class="row">
            <?php if(!$blogs->isEmpty()): ?>
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4  col-md-6 col-12">
                    <!-- single-courses -->
                    <div class="single-our-blog mt--30">
                        <div class="our-blog-image">
                            <a href="blog-details.html"><img src="<?php echo e(url('storage/blog/'.$blog->featured_img)); ?>" alt=""></a>
                            <span class="in-our-blog-icon">
                                <img src="<?php echo e(url('frontend/images/icon/our-blog-01.png')); ?>" alt="">
                            </span>
                        </div>
                        <div class="our-blog-contnet">
                            <h5><a href=""><?php echo e($blog->title); ?></a></h5>
                            <div class="post_meta">
                                <!-- <ul>
                                    <li><p>By: <a href="#">Sekh Rana</a></p></li>
                                    <li><p>15 Fab 2018</p></li>
                                </ul> -->
                            </div>
                            <div class="text-justify">
                                <?php echo str_limit($blog->description, 150); ?>
                            </div>
                            
                            
                            <div class="button-block">
                                <a href="<?php echo e(route('blogDetails', $blog->id)); ?>" class="botton-border">Read more</a>
                            </div>
                        </div>
                    </div><!--// single-courses -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Our Blog End -->

    <!-- Project Count Area Start -->
    <div class="project-count-area section-ptb-160 project-count-bg">
        <div class="container">

            <div class="row">
                <div class="col-lg-8  ml-auto mr-auto">
                    <!-- section-title -->
                    <div class="section-title">
                        <h4>about us</h4>
                        <h3 class="text-white">SOME IMPORTANT FACTS</h3>
                    </div><!--// section-title -->
                </div>
            </div>

            <div class="project-count-inner">
                <div class="row">
                    <div class="col-lg-10 ml-auto mr-auto">
                        <div class="row">
                            <div class="col-lg-3 col-sm-6">
                                <!-- counter start -->
                                <div class="counter text-center">
                                    <h3 class="counter-active">6</h3>
                                    <p>Courses</p>
                                </div>
                                <!-- counter end -->
                            </div>
                            <div class="col-lg-3 col-sm-6">
                                <!-- counter start -->
                                <div class="counter text-center">
                                    <h3 class="counter-active">4000</h3>
                                    <p>Q-Bank</p>
                                </div>
                                <!-- counter end -->
                            </div>
                            <div class="col-lg-3 col-sm-6">
                                <!-- counter start -->
                                <div class="counter text-center">
                                    <h3 class="counter-active">100</h3>
                                    <p>Members</p>
                                </div>
                                <!-- counter end -->
                            </div>
                            <div class="col-lg-3 col-sm-6">
                                <!-- counter start -->
                                <div class="counter text-center">
                                    <h3 class="counter-active">10</h3>
                                    <p>Countries</p>
                                </div>
                                <!-- counter end -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Project Count Area End -->

    <!-- Testimonials Area -->
    <div class="testimonials-area grey-bg-image section-ptb">
        <div class="container">
            <div class="row">
                <div class="col-lg-8  ml-auto mr-auto">
                    <!-- section-title -->
                    <div class="section-title-two">
                        <h4>WORKING TOGETHER</h4>
                        <h3>OUR TEAM</h3>
                    </div><!--// section-title -->
                </div>
            </div>

            <div class="row">
                <div class="testimonial-active owl-carousel">
                    <div class="col-lg-8 ml-auto mr-auto">
                        <!-- testimonial-wrap -->
                        <div class="testimonial-wrap text-center">
                            <div class="testimonial-image">
                                <img src="<?php echo e(url('frontend/images/testimonial/testimonial-author-2.png')); ?>" alt="">
                            </div>
                            <div class="testimonial-info">
                                <div class="autor-info">
                                    <h4>DR KHAN</h4>
                                    <h6>Organisational Genius</h6>
                                </div>
                                <p> If you are going to use a passage of Lorem Ipsum, you need to be
                                    sure there isn't anything embarrassing hidden in the middle of text. All  Lorem
                                    Ipsum gators on the Internet tend to repeat</p>
                            </div>
                        </div><!--// testimonial-wrap -->
                    </div>
                    <div class="col-lg-8 ml-auto mr-auto">
                        <!-- testimonial-wrap -->
                        <div class="testimonial-wrap text-center">
                            <div class="testimonial-image">
                                <img src="<?php echo e(url('frontend/images/testimonial/testimonial-author-2.png')); ?>" alt="">
                            </div>
                            <div class="testimonial-info">
                                <div class="autor-info">
                                    <h4>MRS JEANETTE MCCLELLAN</h4>
                                    <h6>Q-Bank Writing Queen</h6>
                                </div>
                                <p> If you are going to use a passage of Lorem Ipsum, you need to be
                                    sure there isn't anything embarrassing hidden in the middle of text. All  Lorem
                                    Ipsum gators on the Internet tend to repeat</p>
                            </div>
                        </div><!--// testimonial-wrap -->
                    </div>
                    <div class="col-lg-8 ml-auto mr-auto">
                        <!-- testimonial-wrap -->
                        <div class="testimonial-wrap text-center">
                            <div class="testimonial-image">
                                <img src="<?php echo e(url('frontend/images/testimonial/testimonial-author-1.png')); ?>" alt="">
                            </div>
                            <div class="testimonial-info">
                                <div class="autor-info">
                                    <h4>DR SALIK JAVED</h4>
                                    <h6>Revision Material Guru</h6>
                                </div>
                                <p> If you are going to use a passage of Lorem Ipsum, you need to be
                                    sure there isn't anything embarrassing hidden in the middle of text. All  Lorem
                                    Ipsum gators on the Internet tend to repeat</p>
                            </div>
                        </div><!--// testimonial-wrap -->
                    </div>

                    <div class="col-lg-8 ml-auto mr-auto">
                        <!-- testimonial-wrap -->
                        <div class="testimonial-wrap text-center">
                            <div class="testimonial-image">
                                <img src="<?php echo e(url('frontend/images/testimonial/testimonial-author-1.png')); ?>" alt="">
                            </div>
                            <div class="testimonial-info">
                                <div class="autor-info">
                                    <h4>DR TAHIR ZAIB</h4>
                                    <h6>Clinical Expert</h6>
                                </div>
                                <p> If you are going to use a passage of Lorem Ipsum, you need to be
                                    sure there isn't anything embarrassing hidden in the middle of text. All  Lorem
                                    Ipsum gators on the Internet tend to repeat</p>
                            </div>
                        </div><!--// testimonial-wrap -->
                    </div>

                    <div class="col-lg-8 ml-auto mr-auto">
                        <!-- testimonial-wrap -->
                        <div class="testimonial-wrap text-center">
                            <div class="testimonial-image">
                                <img src="<?php echo e(url('frontend/images/testimonial/testimonial-author-1.png')); ?>" alt="">
                            </div>
                            <div class="testimonial-info">
                                <div class="autor-info">
                                    <h4>DR JALIL KHAN</h4>
                                    <h6>General Practice Specialist</h6>
                                </div>
                                <p> If you are going to use a passage of Lorem Ipsum, you need to be
                                    sure there isn't anything embarrassing hidden in the middle of text. All  Lorem
                                    Ipsum gators on the Internet tend to repeat</p>
                            </div>
                        </div><!--// testimonial-wrap -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--// Testimonials Area -->
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/frontend/index.blade.php ENDPATH**/ ?>