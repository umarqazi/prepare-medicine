<?php $__env->startSection('content'); ?>

<div class='container'>
    <div class='page_banner_img_common'>
        <img src='/frontend/images/pages-banner.png' class='img-fluid'>
        <div class='overlay__'>
            <p>All Courses</p>
        </div>
    </div>
    
    
    <div class="row">
        <?php if(!$course_list->isEmpty()): ?>
        <?php $__currentLoopData = $course_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 col-md-6 col-12">
            <!-- single-courses -->
            <div class="single-popular-courses mt--30">
                <div class="popular-courses-image">
                    <a href="<?php echo e(route('courseDetails.show', $course->id)); ?>"><img src="<?php echo e(url('storage/course/'.$course->featured_img)); ?>" alt=""></a>
                </div>
                <div class="popular-courses-contnet">
                    
                    <div class="post_meta">
                        <ul>
                            <li><a href="<?php echo e(route('courseDetails.show', $course->id)); ?>"><?php echo e($course->title); ?></a></li>
                            
                        </ul>
                    </div>
                    <p class='text-justify'><?php echo str_limit($course->description, 80); ?></p>
                    <div class="button-block">
                        <a href="<?php echo e(route('subscription_plans', $course->title)); ?>" class="botton-border">SUBSCRIBE</a>
                    </div>
                </div>
            </div><!--// single-courses -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </div>
    
    <div class='col-12'>
        <?php echo $course_list->render(); ?>

    </div>
    <br/>
</div>
            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/preparemedicine.com/resources/views/frontend/course/course-list.blade.php ENDPATH**/ ?>