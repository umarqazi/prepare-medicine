<?php $__env->startSection('content'); ?>

<br>


    <div class="container">
        <div class='page_banner_img_common'>
            <img src='/frontend/images/pages-banner.png' class='img-fluid'>
            <div class='overlay__'>
                <p>Plab Community Add Question</p>
            </div>
        </div>
        
        <h2 class="text-center" style="font-size: 35px;text-align: center;">
            Add Questions to Plab Community
        </h2>
        <br>
        <div class="col-sm-12">
            <p class="text-justify">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </p>
        </div>
        <br><br>
        
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <a href="<?php echo e(url('user/question/add/single')); ?>" class="btn btn-spinner col-12" style="
                        background: green;
                        text-transform: uppercase;
                        border-radius: 5px;
                        box-sizing: border-box;
                        box-shadow: 0px 0px 20px 0px #444;
                    ">Add Question</a>
                </div>
            </div>
    </div>



<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/plabone.preparemedicine.com/resources/views/frontend/add-questions.blade.php ENDPATH**/ ?>