<?php $__env->startSection('js-css'); ?>
    <style>
        .panel-white{
            background: white;
            padding: 10px;
        }
        .btn-left{
            float: right;
        }
        .delete{
            color: red;
            margin-left: 5px;
        }
        .edit , .delete{
            font-size: 25px;
        }
        .edit {
            cursor: pointer;
        }


        .fa-remove{
            color: #fff !important
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="panel panel-white">
    <div class="panel-heading clearfix">
        <h4 class="panel-title">Subscription Requests</h4>
    </div>
    <br><br>
    <div class="panel-body">
        <?php echo $__env->make('msg.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>User Name</th>
                        <th>For</th>
                        <th>Request at</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td scope="row"><?php echo e($key+1); ?></td>
                            <td ><?php echo e($item->user_info->f_name); ?> <?php echo e($item->user_info->s_name); ?></td>
                            <td >Refugee Doctors Plan</td>
                            <td><?php echo e($item->created_at->format('d-m-y H:m')); ?></td>
                            <td>
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#approvalModal<?php echo e($item->id); ?>"
                                        style="background: #2B3069; border:none;margin-right: 4px"><i class="fa fa-check"></i></button>
                                <a onclick="return confirm('Are you sure?')" class="btn btn-danger btn-sm" href="<?php echo e(route('subscribers_requests_reject', $item->id)); ?>"><i class="fa fa-times"></i></a>
                            </td>
                        </tr>

                        <!-- Modal -->
                        <div class="modal fade" id="approvalModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Request Approval</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(route('subscribers_requests_approve')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($item->id); ?>">
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Enter Expire Date</label>
                                            <input type="date" class="form-control" name="expire_date" required="1">
                                        </div>
                                        <input type="submit" value="APPROVE" class="btn btn-success col-12">
                                    </form>
                                </div>
                            </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <span><?php echo $data->render(); ?></span>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/backend/requests.blade.php ENDPATH**/ ?>