<?php $__env->startSection('content'); ?>
    

    <div class="container-fluid" style="padding-left: 30px; padding-right: 30px"> 
        <div class='page_banner_img_common'>
            <img src='/frontend/images/pages-banner.png' class='img-fluid'>
            <div class='overlay__'>
                <p>Random Mock </p>
            </div>
        </div>
        <h2 style="font-size: 25px;text-align: center;">RANDOM MOCKS</h2>
        <p style="text-align: justify;">
               Your opportunity to test yourself on randomly generated full simulation of the GMC PlAB-1 Exam, which timed 3:00 hours for 180 MCQs.
        <br>
               These are timed, random mock exams using a selection of questions from our extensive Q Bank. You may find you have answered a question previously, but it is likely that many are new to you. This gives you the chance to time yourself to exam conditions for the PLAB 1
        </p>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
    
        <?php endif; ?>
        
       <div class="row" style="padding-left: 35px; padding-right: 35px">
            <?php $__currentLoopData = $expired_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($key%4 == '0'): ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                            <a href="<?php echo e(url('q-bank/random/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                                <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                                <span style="margin-top:17px">MOCK <?php echo e($key+1); ?></span>
                            </a>
                        </div>
                    <?php elseif($key%3 == '0'): ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                            <a href="<?php echo e(url('q-bank/random/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                                <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                                <span style="margin-top:17px">MOCk <?php echo e($key+1); ?></span>
                            </a>
                        </div>
                    <?php elseif($key%2 == '0'): ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                            <a href="<?php echo e(url('q-bank/random/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                                <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                                <span style="margin-top:17px">MOCK <?php echo e($key+1); ?></span>
                            </a>
                        </div>
                    <?php else: ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                            <a href="<?php echo e(url('q-bank/random/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden;background-color: #2C3069">
                                <img src="<?php echo e(url('storage/photos/mock/random-mock/general-icons.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                                <span style="margin-top:17px">MOCK <?php echo e($key+1); ?></span>
                            </a>
                        </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($exists_data != '0'): ?>
                <?php $__currentLoopData = $continue_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                        <a href="<?php echo e(url('q-bank/random/exam/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden">
                            <img src="<?php echo e(url('storage/photos/mock/random-mock/continue-mock.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                            <span style="margin-top:17px"><?php echo e('Continue Mock'); ?></span>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                    <a href="<?php echo e(url('q-bank/random')); ?>" class="btn btn-spinner col-12 p-0" style="padding:0;border-radius:10px;overflow:hidden">
                        <img src="<?php echo e(url('storage/photos/mock/random-mock/new-mock.png')); ?>" alt="" style="width:35%;float:left;height:55px;">
                        <span style="margin-top:17px"><?php echo e('New Mock'); ?></span>
                    </a>
                </div>
            <?php endif; ?>
        </div>
     </div>
 
    <br>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/preparemedicine.com/resources/views/frontend/random-mock.blade.php ENDPATH**/ ?>