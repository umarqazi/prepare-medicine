<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\question_bank_project\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>