<?php $__env->startSection('js-css'); ?>
<script type="text/javascript">
    function FindNext () {
        var str = document.getElementById ("findInput").value;
        if (str == "") {
            alert ("Please enter some text to search!");
            return;
        }
        
        if (window.find) {        // Firefox, Google Chrome, Safari
            var found = window.find (str);
            if (!found) {
                alert ("The following text was not found:\n" + str);
            }
        }
        else {
            alert ("Your browser does not support this example!");
        }
    }
</script>
<style>
    /* Labels for checked inputs */
    input:checked + label {
        color: #0161C3;
    }
    /* checkbox && radio */
    .form-radio
    {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        display: inline-block;
        position: relative;
        background-color: #fff;
        color: #666;
        top: 10px;
        height: 30px;
        width: 30px;
        border: 0;
        border-radius: 0;
        cursor: pointer;     
        margin-right: 7px;
        outline: none;
    }
    .a::before{
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
        content: 'A';
    }
    .b::before{
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
        content: 'B';
    }
    .c::before{
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
        content: 'C';
    }
    .d::before{
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
        content: 'D';
    }
    .e::before{
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
        content: 'E';
    }
    .form-radio:checked::before
    {
        position: absolute;
        font: 13px/1 'Open Sans', sans-serif;
        left: 11px;
        top: 7px;
    }
    .form-radio:hover
    {
        background-color: #f7f7f7;
    }
    .form-radio:checked
    {
        background-color: #f1f1f1;
    }
    label
    {
        font: 15px/1.7 'Open Sans', sans-serif;
        color: #333;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        cursor: pointer;
    } 
</style>
<style>
    body{
        background: #F4F1EC;
    }
    .inline{
        display: inline;
    }
    .right{
        float: right;
    }
    .search-box{
        background: #ffffff;
        width: 40px; 
        height: 40px; 
        padding: 6px 0px; 
        border-radius: 20px; 
        text-align: center;
    }
    .comment-wrap{
        width: 100%;
        height: 220px;
        overflow-y: scroll;
    }
    .bg{
        background: #F4F1EC;
    }
    .success{
        background: #C2F7CF;
    }
    .wrong{
        background: #F9C1C6;
    }
    .active-search-box{
        background: #fff;
        -webkit-box-shadow: 0px 0px 15px 3px rgba(0,0,0,0.75);
        -moz-box-shadow: 0px 0px 15px 3px rgba(0,0,0,0.75);
        box-shadow: 0px 0px 15px 3px rgba(0,0,0,0.75);
    }
    .center{
        margin:0 auto;
        margin-top: 15px;
        margin-bottom: 15px;
        /* background: #DBDBDB; */
    }
    .cart-tab{
        margin:2.5%;
    }
    .radius{
        border-radius: 5%;
    }
</style>
<style>
    /* chart style */
    .horizontal .progress-bar {
    float: left;
    height: 45px;
    width: 100%;
    padding: 12px 0;
    }

    .horizontal .progress-track {
    position: relative;
    width: 100%;
    height: 20px;
    background: #ebebeb;
    }

    .horizontal .progress-fill {
    position: relative;
    background: #666;
    height: 20px;
    width: 50%;
    color: #fff;
    text-align: center;
    font-family: "Lato","Verdana",sans-serif;
    font-size: 12px;
    line-height: 20px;
    }

    .rounded .progress-track,
    .rounded .progress-fill {
    border-radius: 3px;
    box-shadow: inset 0 0 5px rgba(0,0,0,.2);
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br><br>


    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                
                <div class="col-md-3" id="pc">
                    <div class="col-12">
                        <div class="row">
                            <?php for($i = 1; $i <= $total_question; $i++): ?>

                                <?php if(isset($_GET['page'])): ?>
                                    <?php if($i == $_GET['page']): ?>
                                        <?php if(!empty($mark[$i-1]->status)): ?>
                                            <?php if( $mark[$i-1]->status == "1"): ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1" style="background:#81DB97"><span><?php echo e($i); ?></span></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1" style="background:#fb5252"><span><?php echo e($i); ?></span></a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if(!empty($mark[$i-1]->status)): ?>
                                            <?php if( $mark[$i-1]->status == "1"): ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1" style="background:#81DB97"><span><?php echo e($i); ?></span></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1" style="background:#fb5252"><span><?php echo e($i); ?></span></a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($i == '1'): ?>
                                        <?php if(!empty($mark[$i-1]->status)): ?>
                                            <?php if( $mark[$i-1]->status == "1"): ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1" style="background:#81DB97"><span><?php echo e($i); ?></span></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1" style="background:#fb5252"><span><?php echo e($i); ?></span></a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                    <?php if(!empty($mark[$i-1]->status)): ?>
                                        <?php if( $mark[$i-1]->status == "1"): ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1" style="background:#81DB97"><span><?php echo e($i); ?></span></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1" style="background:#fb5252"><span><?php echo e($i); ?></span></a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>

                            <?php endfor; ?>
                        </div>
                    </div>
                    <br>
                    <!-- question chart -->
                    
                    <div class="center">
                        <table width="95%" class="cart-tab">
                            <p class="text-center">Question Status</p>
                            <div class="container horizontal rounded">
                                <tr>
                                    <td width="10%">A</td>
                                    <td width="90%">
                                        <div class="horizontal">
                                            <div class="progress-track">
                                                <div class="progress-fill">
                                                    <span>
                                                        <?php if($item->type == '0'): ?>
                                                            <?php echo e(round(((App\mockquestion::where('ques_id',$item->ques_id)->where('user_ans','0')->count())/(App\mockquestion::where('ques_id',$item->ques_id)->count()))*100 )); ?>%
                                                        <?php else: ?>
                                                            <?php
                                                                $total = App\mockquestion::where('ques_id',$item->ques_id)->count();
                                                                $total_data = App\mockquestion::where('ques_id',$item->ques_id)->get();
                                                                $static_data = 0;
                                                                foreach ($total_data as $key => $value) {
                                                                    $exploda_data = explode('-',$value->user_ans);
                                                                    if(in_array('0',$exploda_data)){
                                                                        $static_data = $static_data+1;
                                                                    }
                                                                }
                                                                echo round((($static_data/$total)*100))."%";
                                                            ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="10%">B</td>
                                    <td width="90%">
                                        <div class="horizontal">
                                            <div class="progress-track">
                                                <div class="progress-fill">
                                                    <span>
                                                        <?php if($item->type == '0'): ?>
                                                            <?php echo e(round(((App\mockquestion::where('ques_id',$item->ques_id)->where('user_ans','1')->count())/(App\mockquestion::where('ques_id',$item->ques_id)->count()))*100 )); ?>%
                                                        <?php else: ?>
                                                            <?php
                                                                $total = App\mockquestion::where('ques_id',$item->ques_id)->count();
                                                                $total_data = App\mockquestion::where('ques_id',$item->ques_id)->get();
                                                                $static_data = 0;
                                                                foreach ($total_data as $key => $value) {
                                                                    $exploda_data = explode('-',$value->user_ans);
                                                                    if(in_array('1',$exploda_data)){
                                                                        $static_data = $static_data+1;
                                                                    }
                                                                }
                                                                echo round((($static_data/$total)*100))."%";
                                                            ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="10%">C</td>
                                    <td width="90%">
                                        <div class="horizontal">
                                            <div class="progress-track">
                                                <div class="progress-fill">
                                                    <span>
                                                        <?php if($item->type == '0'): ?>
                                                            <?php echo e(round(((App\mockquestion::where('ques_id',$item->ques_id)->where('user_ans','2')->count())/(App\mockquestion::where('ques_id',$item->ques_id)->count()))*100 )); ?>%
                                                        <?php else: ?>
                                                            <?php
                                                                $total = App\mockquestion::where('ques_id',$item->ques_id)->count();
                                                                $total_data = App\mockquestion::where('ques_id',$item->ques_id)->get();
                                                                $static_data = 0;
                                                                foreach ($total_data as $key => $value) {
                                                                    $exploda_data = explode('-',$value->user_ans);
                                                                    if(in_array('2',$exploda_data)){
                                                                        $static_data = $static_data+1;
                                                                    }
                                                                }
                                                                echo round((($static_data/$total)*100))."%";
                                                            ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="10%">D</td>
                                    <td width="90%">
                                        <div class="horizontal">
                                            <div class="progress-track">
                                                <div class="progress-fill">
                                                    <span>
                                                        <?php if($item->type == '0'): ?>
                                                            <?php echo e(round(((App\mockquestion::where('ques_id',$item->ques_id)->where('user_ans','3')->count())/(App\mockquestion::where('ques_id',$item->ques_id)->count()))*100 )); ?>%
                                                        <?php else: ?>
                                                            <?php
                                                                $total = App\mockquestion::where('ques_id',$item->ques_id)->count();
                                                                $total_data = App\mockquestion::where('ques_id',$item->ques_id)->get();
                                                                $static_data = 0;
                                                                foreach ($total_data as $key => $value) {
                                                                    $exploda_data = explode('-',$value->user_ans);
                                                                    if(in_array('3',$exploda_data)){
                                                                        $static_data = $static_data+1;
                                                                    }
                                                                }
                                                                echo round((($static_data/$total)*100))."%";
                                                            ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="10%">E</td>
                                    <td width="90%">
                                        <div class="horizontal">
                                            <div class="progress-track">
                                                <div class="progress-fill">
                                                    <span>
                                                        <?php if($item->type == '0'): ?>
                                                            <?php echo e(round(((App\mockquestion::where('ques_id',$item->ques_id)->where('user_ans','4')->count())/(App\mockquestion::where('ques_id',$item->ques_id)->count()))*100 )); ?>%
                                                        <?php else: ?>
                                                            <?php
                                                                $total = App\mockquestion::where('ques_id',$item->ques_id)->count();
                                                                $total_data = App\mockquestion::where('ques_id',$item->ques_id)->get();
                                                                $static_data = 0;
                                                                foreach ($total_data as $key => $value) {
                                                                    $exploda_data = explode('-',$value->user_ans);
                                                                    if(in_array('4',$exploda_data)){
                                                                        $static_data = $static_data+1;
                                                                    }
                                                                }
                                                                echo round((($static_data/$total)*100))."%";
                                                            ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </div>
                        </table>
                    </div>
                        
                </div>

                
                <div class="col-md-9">
                    <div class="col-12">
                    
                        <div>
                            <?php if(isset($_GET['page'])): ?>
                                Question <?php echo e($_GET['page']); ?> of <?php echo e($total_question); ?>

                            <?php endif; ?>
                            <?php if(!empty($item->mocques_ques->question_flag->where('user_id',Auth::user()->id)[0]) ): ?>
                                <a href="<?php echo e(url('q-bank/drop/flag/'.$item->mocques_ques->question_flag->where('user_id',Auth::user()->id)[0]->id)); ?>" style="color:green;font-size: 18px;"><i class="fa fa-bookmark" aria-hidden="true"></i></a>
                            <?php else: ?>
                                <a href="<?php echo e(url('q-bank/add/flag/'.$item->mocques_ques->id)); ?>" style="font-size: 18px;"><i class="fa fa-bookmark" aria-hidden="true"></i></a>
                            <?php endif; ?>
                            <br>
                            <div>
                                <p style="color: #8a9591;background:#81DB97;display:inline-block;padding:0 8px;">Question Id : <?php echo e($item->search_id); ?></p>
                                <p style="display:inline-block;" class="mr-1">
                                    <a style="background:#81DB97;display:inline-block;padding:0 15px;" type="button" data-toggle="collapse" data-target="#collapseExample" aria-expanded="false" aria-controls="collapseExample">Hint</a>
                                </p>
                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="border-radius:10px;">Lab Values</button>
                            </div>
                            <div class="collapse" id="collapseExample">
                                <?php if(!empty($item->hint) && $item->hint != null): ?>
                                    <?php echo $item->hint; ?>

                                <?php else: ?>
                                    No hint defined !!
                                <?php endif; ?>
                            </div>
                            <?php echo $item->question; ?>


                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-xl" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="exampleModalLabel">Lab Values</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="form-group col-12">
                                                <input type="text" class="form-control" id="findInput" placeholder="find your information...">
                                            </div>
                                            <button type="submit" class="btn btn-info col-12" onclick="FindNext ();">find</button>
                                            <br>
                                            <div id="hint">
                                                <?php echo $lab; ?>

                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br>
                                <?php if($item->status == '1'): ?>
                                    <div class="alert alert-success mt-1" role="alert">
                                        Your Answer Was Correct
                                    </div>
                                <?php elseif($item->status == '0'): ?>
                                    <div class="alert alert-danger mt-1" role="alert">
                                            Your Answer Was Wrong
                                    </div>
                                <?php else: ?>
                                    <div class="alert alert-danger mt-1" role="alert">
                                            Your Answer Was Wrong
                                    </div>
                                <?php endif; ?>
                        </div>
                        
                        <div class="col-12">
                            
                            <?php if($item->type == '0'): ?>
                                <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($key == '0'): ?>
                                        <?php if($key == $item->ans): ?>
                                            <div class="success mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio a">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php elseif($key == $item->user_ans): ?>
                                            <?php if('0' ==  $item->user_ans): ?>
                                                <div class="wrong mb-2 pb-2 radius">
                                                    <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio a">
                                                    <p class="inline"><?php echo e($value->ans); ?></p>
                                                </div>
                                            <?php else: ?>
                                                <div class="mb-2 pb-2 radius">
                                                    <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio a">
                                                    <p class="inline"><?php echo e($value->ans); ?></p>
                                                </div>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <div class="mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio a">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    <?php elseif($key == '1'): ?>
                                        <?php if($key == $item->ans): ?>
                                            <div class="success mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio b">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php elseif($key == $item->user_ans): ?>
                                            <?php if(empty($item->user_ans)): ?>
                                                <?php continue; ?>
                                            <?php endif; ?>
                                            <div class="wrong mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio b">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php else: ?>
                                            <div class="mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio b">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    <?php elseif($key == '2'): ?>
                                        <?php if($key == $item->ans): ?>
                                            <div class="success mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio c">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php elseif($key == $item->user_ans): ?>
                                            <?php if(empty($item->user_ans)): ?>
                                                <?php continue; ?>
                                            <?php endif; ?>
                                            <div class="wrong mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio c">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php else: ?>
                                            <div class="mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio c">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    <?php elseif($key == '3'): ?>
                                        <?php if($key == $item->ans): ?>
                                            <div class="success mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio d">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php elseif($key == $item->user_ans): ?>
                                            <?php if(empty($item->user_ans)): ?>
                                                <?php continue; ?>
                                            <?php endif; ?>
                                            <div class="wrong mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio d">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php else: ?>
                                            <div class="mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio d">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    <?php elseif($key == '4'): ?>
                                        <?php if($key == $item->ans): ?>
                                            <div class="success mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio e">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php elseif($key == $item->user_ans): ?>
                                            <?php if(empty($item->user_ans)): ?>
                                                <?php continue; ?>
                                            <?php endif; ?>
                                            <div class="wrong mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio e">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php else: ?>
                                            <div class="mb-2 pb-2 radius">
                                                <input type="radio" name="answer" value="<?php echo e($key); ?>" class="form-radio e">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            
                            <?php if($item->type == '1'): ?>
                                <?php $__currentLoopData = $item->mocques_ans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($key == '0'): ?>
                                            <div id="muli-ans<?php echo e($key); ?>" class="mb-2 pb-2 radius">
                                                <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio a">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php elseif($key == '1'): ?>
                                            <div id="muli-ans<?php echo e($key); ?>" class="mb-2 pb-2 radius">
                                                <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio b">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php elseif($key == '2'): ?>
                                            <div id="muli-ans<?php echo e($key); ?>" class="mb-2 pb-2 radius">
                                                <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio c">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php elseif($key == '3'): ?>
                                            <div id="muli-ans<?php echo e($key); ?>" class="mb-2 pb-2 radius">
                                                <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio d">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php elseif($key == '4'): ?>
                                            <div id="muli-ans<?php echo e($key); ?>" class="mb-2 pb-2 radius">
                                                <input type="checkbox" name="answer[]" value="<?php echo e($key); ?>" class="form-radio e">
                                                <p class="inline"><?php echo e($value->ans); ?></p>
                                            </div>
                                        <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $answers = explode('-',$item->ans);
                                ?>
                                <?php $__currentLoopData = $answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <script>
                                        document.querySelector('#muli-ans<?php echo e($answer); ?>').style.background = "#C2F7CF";
                                    </script>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            

                        </div>
                        <?php if($data->hasPages()): ?>
                            <table style="margin:0 auto">
                                <tr>
                                    
                                    <?php if($data->onFirstPage()): ?>
                                        <td> <i class="fa fa-arrow-circle-left disabled" style="font-size:36px"></i> </td>
                                    <?php else: ?>
                                            <td> <a href="<?php echo e($data->previousPageUrl()); ?>"><i class="fa fa-arrow-circle-left" style="font-size:36px;color:#63BA52"></i></a> </td>
                                    <?php endif; ?>
                                    
                                    <?php if($data->hasMorePages()): ?>
                                            <td> <a href="<?php echo e($data->nextPageUrl()); ?>" ><i class="fa fa-arrow-circle-right ml-5" style="font-size:36px;color:#63BA52"></i></a> </td>
                                    <?php else: ?>
                                            <td> <i class="fa fa-arrow-circle-right disabled ml-5" style="font-size:36px"></i> </td>
                                    <?php endif; ?>
                                </tr>
                            </table>
                        <?php endif; ?>
                        <br><br>
                        <div>
                            <h3>Explaination</h3>
                            <?php echo $item->explanation; ?>

                        </div>
                    </div>
                </div>

                
                <div class="col-md-3" id="mobile">
                    <br>
                    <div class="col-12">
                        <div class="row">
                            <?php for($i = 1; $i <= $total_question; $i++): ?>

                                <?php if(isset($_GET['page'])): ?>
                                    <?php if($i == $_GET['page']): ?>
                                        <?php if(!empty($mark[$i-1]->status)): ?>
                                            <?php if( $mark[$i-1]->status == "1"): ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1" style="background:#81DB97"><span><?php echo e($i); ?></span></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1" style="background:#fb5252"><span><?php echo e($i); ?></span></a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <?php if(!empty($mark[$i-1]->status)): ?>
                                            <?php if( $mark[$i-1]->status == "1"): ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1" style="background:#81DB97"><span><?php echo e($i); ?></span></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1" style="background:#fb5252"><span><?php echo e($i); ?></span></a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if($i == '1'): ?>
                                        <?php if(!empty($mark[$i-1]->status)): ?>
                                            <?php if( $mark[$i-1]->status == "1"): ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1" style="background:#81DB97"><span><?php echo e($i); ?></span></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1" style="background:#fb5252"><span><?php echo e($i); ?></span></a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box active-search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php else: ?>
                                    <?php if(!empty($mark[$i-1]->status)): ?>
                                        <?php if( $mark[$i-1]->status == "1"): ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1" style="background:#81DB97"><span><?php echo e($i); ?></span></a>
                                            <?php else: ?>
                                                <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1" style="background:#fb5252"><span><?php echo e($i); ?></span></a>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <a href="<?php echo e(url('q-bank/random/exam/result/'.$id.'?page='.$i)); ?>" class="search-box m-1 col-x-1"><span><?php echo e($i); ?></span></a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endif; ?>

                            <?php endfor; ?>
                        </div>
                    </div>
                    <br>
                    <!-- question chart -->
                    
                    <div class="center">
                        <table width="95%" class="cart-tab">
                            <p class="text-center">Question Status</p>
                            <div class="container horizontal rounded">
                                <tr>
                                    <td width="10%">A</td>
                                    <td width="90%">
                                        <div class="horizontal">
                                            <div class="progress-track">
                                                <div class="progress-fill">
                                                    <span>
                                                        <?php if($item->type == '0'): ?>
                                                            <?php echo e(((App\mockquestion::where('ques_id',$item->ques_id)->where('user_ans','0')->count())/(App\mockquestion::where('ques_id',$item->ques_id)->count()))*100); ?>%
                                                        <?php else: ?>
                                                            <?php
                                                                $total = App\mockquestion::where('ques_id',$item->ques_id)->count();
                                                                $total_data = App\mockquestion::where('ques_id',$item->ques_id)->get();
                                                                $static_data = 0;
                                                                foreach ($total_data as $key => $value) {
                                                                    $exploda_data = explode('-',$value->user_ans);
                                                                    if(in_array('0',$exploda_data)){
                                                                        $static_data = $static_data+1;
                                                                    }
                                                                }
                                                                echo (($static_data/$total)*100)."%";
                                                            ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="10%">B</td>
                                    <td width="90%">
                                        <div class="horizontal">
                                            <div class="progress-track">
                                                <div class="progress-fill">
                                                    <span>
                                                        <?php if($item->type == '0'): ?>
                                                            <?php echo e(((App\mockquestion::where('ques_id',$item->ques_id)->where('user_ans','1')->count())/(App\mockquestion::where('ques_id',$item->ques_id)->count()))*100); ?>%
                                                        <?php else: ?>
                                                            <?php
                                                                $total = App\mockquestion::where('ques_id',$item->ques_id)->count();
                                                                $total_data = App\mockquestion::where('ques_id',$item->ques_id)->get();
                                                                $static_data = 0;
                                                                foreach ($total_data as $key => $value) {
                                                                    $exploda_data = explode('-',$value->user_ans);
                                                                    if(in_array('1',$exploda_data)){
                                                                        $static_data = $static_data+1;
                                                                    }
                                                                }
                                                                echo (($static_data/$total)*100)."%";
                                                            ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="10%">C</td>
                                    <td width="90%">
                                        <div class="horizontal">
                                            <div class="progress-track">
                                                <div class="progress-fill">
                                                    <span>
                                                        <?php if($item->type == '0'): ?>
                                                            <?php echo e(((App\mockquestion::where('ques_id',$item->ques_id)->where('user_ans','2')->count())/(App\mockquestion::where('ques_id',$item->ques_id)->count()))*100); ?>%
                                                        <?php else: ?>
                                                            <?php
                                                                $total = App\mockquestion::where('ques_id',$item->ques_id)->count();
                                                                $total_data = App\mockquestion::where('ques_id',$item->ques_id)->get();
                                                                $static_data = 0;
                                                                foreach ($total_data as $key => $value) {
                                                                    $exploda_data = explode('-',$value->user_ans);
                                                                    if(in_array('2',$exploda_data)){
                                                                        $static_data = $static_data+1;
                                                                    }
                                                                }
                                                                echo (($static_data/$total)*100)."%";
                                                            ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="10%">D</td>
                                    <td width="90%">
                                        <div class="horizontal">
                                            <div class="progress-track">
                                                <div class="progress-fill">
                                                    <span>
                                                        <?php if($item->type == '0'): ?>
                                                            <?php echo e(((App\mockquestion::where('ques_id',$item->ques_id)->where('user_ans','3')->count())/(App\mockquestion::where('ques_id',$item->ques_id)->count()))*100); ?>%
                                                        <?php else: ?>
                                                            <?php
                                                                $total = App\mockquestion::where('ques_id',$item->ques_id)->count();
                                                                $total_data = App\mockquestion::where('ques_id',$item->ques_id)->get();
                                                                $static_data = 0;
                                                                foreach ($total_data as $key => $value) {
                                                                    $exploda_data = explode('-',$value->user_ans);
                                                                    if(in_array('3',$exploda_data)){
                                                                        $static_data = $static_data+1;
                                                                    }
                                                                }
                                                                echo (($static_data/$total)*100)."%";
                                                            ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td width="10%">E</td>
                                    <td width="90%">
                                        <div class="horizontal">
                                            <div class="progress-track">
                                                <div class="progress-fill">
                                                    <span>
                                                        <?php if($item->type == '0'): ?>
                                                            <?php echo e(((App\mockquestion::where('ques_id',$item->ques_id)->where('user_ans','4')->count())/(App\mockquestion::where('ques_id',$item->ques_id)->count()))*100); ?>%
                                                        <?php else: ?>
                                                            <?php
                                                                $total = App\mockquestion::where('ques_id',$item->ques_id)->count();
                                                                $total_data = App\mockquestion::where('ques_id',$item->ques_id)->get();
                                                                $static_data = 0;
                                                                foreach ($total_data as $key => $value) {
                                                                    $exploda_data = explode('-',$value->user_ans);
                                                                    if(in_array('4',$exploda_data)){
                                                                        $static_data = $static_data+1;
                                                                    }
                                                                }
                                                                echo (($static_data/$total)*100)."%";
                                                            ?>
                                                        <?php endif; ?>
                                                    </span>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            </div>
                        </table>
                    </div>
                        
                </div>

                
                <div class="col-md-3">
                </div>
                <div class="col-md-9">
                    <br>
                    <h3>Comments</h3>
                    <?php if(isset($item->mocques_ques->question_comment[0])): ?>
                        <div class="card">
                            <div class="card-body" style="background: #E1E0DD;">
                                <div class="comment-wrap">
                                    <?php $__currentLoopData = $item->mocques_ques->question_comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-12 bg mb-2 p-4" style="width: 98%;margin-right: 2%;:">
                                            <h5 style="color: #2F4D36;">
                                                <?php echo e($value->name); ?>

                                                <?php if($value->user_id == Auth::user()->id): ?>
                                                    <a href="<?php echo e(url('comment/'.$value->id)); ?>"><i class="fa fa-times text-danger" aria-hidden="true"></i></a>
                                                <?php endif; ?>
                                            </h5>
                                            <p><?php echo e($value->comment); ?></p>
                                            <p style="text-align:end;"><?php echo e($value->created_at); ?></p>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <?php if(Auth::user()->f_name): ?>
                        <form action="<?php echo e(url('comment/store')); ?>" method="post" class="mt-3">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="question_id" value="<?php echo e($item->ques_id); ?>">
                            <textarea name="comment" class="form-control" placeholder="Write Your Comment !!"></textarea>
                            <input type="submit" value="Submit" class="btn btn-success mt-3 mb-3 right col-md-3" style="background: green;">
                        </form>
                    <?php endif; ?>
                    <br><br><br>
                </div>
               
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>



<br><br><br><br>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        // chart js
        $('.horizontal .progress-fill span').each(function(){
            var percent = $(this).html();
            $(this).parent().css('width', percent);
        });


        $('.vertical .progress-fill span').each(function(){
            var percent = $(this).html();
            var pTop = 100 - ( percent.slice(0, percent.length - 1) ) + "%";
            $(this).parent().css({
                'height' : percent,
                'top' : pTop
            });
        });
    </script>
    <script>
        window.addEventListener("resize", responsive);

        function responsive() {
            if(screen.width > 767){
                document.getElementById("mobile").style.display = "none";
                document.getElementById("pc").style.display = "block";
            }else{
                document.getElementById("pc").style.display = "none";
                document.getElementById("mobile").style.display = "block";
            }
        }
        
        if(screen.width > 767){
            document.getElementById("mobile").style.display = "none";
            document.getElementById("pc").style.display = "block";
        }else{
            document.getElementById("pc").style.display = "none";
            document.getElementById("mobile").style.display = "block";
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project emon vai\question_bank\resources\views/frontend/mock-exam-result.blade.php ENDPATH**/ ?>