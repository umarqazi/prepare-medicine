<?php $__env->startSection('js-css'); ?>
    <style>
        .panel-white{
            background: white;
            padding: 10px;
        }
        .btn-left{
            float: right;
        }
        .delete{
            color: red;
            margin-left: 5px;
        }
        .edit , .delete{
            font-size: 25px;
        }
        .edit {
            cursor: pointer;
        }

        .btn_custom_style{
            background-color: #ddd;
            color: #000
        }
        .fa-remove{
            color: #fff;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="panel panel-white">
    <div class="panel-heading clearfix">
        <h4 class="panel-title">Whatsapp Group</h4>
    </div>
    <div class="panel-heading clearfix btn-left">
        <button class="btn btn_custom_style" data-toggle="modal" data-target="#AddCat">Add Whatsapp Group</button>
    </div>
    <br><br>
    <div class="panel-body">
        <?php echo $__env->make('msg.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Link</th>
                        <th>Image</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($data->firstItem()+$key); ?></th>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->link); ?></td>
                            <td><img src="<?php echo e(url('storage/community-groups/'.$item->cat_img)); ?>" alt="" style="width:100px"></td>
                            <td>
                                <a style="background-color: #0A68D4; color: #fff; border: none;" class="btn btn-sm" data-toggle="modal" data-target="#EditCat<?php echo e($item->id); ?>"><i class="fa fa-edit edit"></i></a>
                                <a style="background-color: red; color: #fff; border: none;" class="btn btn-sm" href="<?php echo e(url('admin/Community/drop/'.$item->id)); ?>"><i class="fa fa-remove delete"></i></a>
                            </td>
                        </tr>

                        <!-- Modal -->
                        <div class="modal fade" id="EditCat<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Edit Whatsapp Group</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                                </div>
                                <div class="modal-body">
                                    <form action="<?php echo e(url('admin/Community/whatsapp/edit/'.$item->id)); ?>" method="post" enctype='multipart/form-data'>
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Group Name</label>
                                            <input type="text" class="form-control" placeholder="Ex : Global.." name="name" value="<?php echo e($item->name); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Link</label>
                                            <input type="text" class="form-control" name="link" value="<?php echo e($item->link); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Image</label>
                                            <input type="file" class="form-control" name="cat_img">
                                        </div>
                                        <input type="submit" value="Update" class="btn btn-success col-12">
                                    </form>
                                </div>
                            </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <span><?php echo e($data->links()); ?></span>
    </div>
</div>>


    <!-- Modal -->
    <div class="modal fade" id="AddCat" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" >
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Add Whatsapp Group</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(url('admin/Community/whatsapp/add')); ?>" method="post" enctype='multipart/form-data'>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Group Name</label>
                        <input type="text" class="form-control" placeholder="Ex : Global.." name="name">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Link</label>
                        <input type="text" class="form-control" name="link">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Image</label>
                        <input type="file" class="form-control" name="cat_img">
                    </div>
                    <input type="submit" value="Place It" class="btn btn-success col-12">
                </form>
            </div>
          </div>
        </div>
      </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/preparemedicine.com/resources/views/backend/whatsapp.blade.php ENDPATH**/ ?>