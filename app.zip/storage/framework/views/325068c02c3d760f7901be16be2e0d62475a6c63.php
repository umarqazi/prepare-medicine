<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <div class='page_banner_img_common'>
            <img src='/frontend/images/pages-banner.png' class='img-fluid'>
            </div>
            <div class='overlay__'>
                <p>Plab One</p>
            </div>
        </div>
        
        
        <?php echo $data; ?>


    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/preparemedicine.com/resources/views/frontend/links-plab-1.blade.php ENDPATH**/ ?>