<?php $__env->startSection('js-css'); ?>

    <style>
        .user-name{
            color:#63BA52;
            display: ruby;
        }
        .user-feedback{
            margin-left: 25px;
        }
        .edit-btn{
            color: green;
        }
        .well h4{
            border-bottom: 3px solid #ddd;
            padding-bottom: 10px
        }
        .notificationsArea table tr th,
        .notificationsArea table tr td{
            border: none;
        }

        .subscribe_button{
            background: #55BA5D !important;
            border-radius: 5px !important;
            font-weight: normal;
        }
        .subscribe_button:hover{
            box-shadow: 1px 4px 7px 2px #777;
            transform: scale(1.1);
            transition: .8s
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
    <br><br>
    <div class="container">
        <div class="row">
            <div class="well" style="width:100%">
                <h4>Notifications</h4>
                <br>
               <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group">
                        <div class="col-md-12">
                            <h5 class="list-group-item-heading  user-name" data-toggle="collapse" data-target="#desc<?php echo e($item->id); ?>" style="cursor:pointer"><?php echo e($item->title); ?></h5>
                            <div class="alert alert-info alert-dismissible list-group-item-text user-feedback collapse" id="desc<?php echo e($item->id); ?>" style="background:rgb(245, 245, 245); border: 1px solid azure;">
                                <p class="" > <?php echo $item->description; ?> </p>
                            </div>
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <?php if(Auth::user()->expeir_date < date('Y-m-d')): ?>
                <div style="border-top:1px solid #ddd">
                    <div class="col-md-12">
                        <div class="notificationsArea">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <th>Your Subscription Plan</th>
                                            <td>
                                                <?php if(Auth::user()->role == 2): ?>
                                                    <?php echo e('Trial'); ?>

                                                <?php elseif(Auth::user()->role == 3): ?>
                                                    <?php echo e('Refugees Doctors'); ?>

                                                <?php elseif(Auth::user()->role == 5): ?>
                                                    <?php echo e('Basic'); ?>

                                                <?php elseif(Auth::user()->role == 6): ?>
                                                    <?php echo e('Standard'); ?>

                                                <?php elseif(Auth::user()->role == 7): ?>
                                                    <?php echo e('Advance'); ?>

                                                <?php elseif(Auth::user()->role == 8): ?>
                                                    <?php echo e('Professional'); ?>

                                                <?php else: ?>
                                                    <?php echo e('Something wrong'); ?>

                                                <?php endif; ?>
                                            </td>
                                            
                                        </tr>
                                        <tr>
                                            <th>Status</th>
                                            <th>
                                                <span style="color: red"><?php echo e('Expired'); ?></span>
                                            </th>
                                        </tr>
                                        <tr>
                                            <th>Expired Date</th>
                                            <th><?php echo e(date('d F Y', strtotime(Auth::user()->expeir_date))); ?></th>
                                        </tr>
                                        <tr>
                                            <td colspan="2">
                                                <a class="subscribe_button btn btn-sm" href="<?php echo e(route('root_page')); ?>#most_popular_courses">UPGRADE PLAN</a>
                                            </td>
                                        </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\question_bank_project\resources\views/frontend/notification.blade.php ENDPATH**/ ?>