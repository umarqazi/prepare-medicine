<?php $__env->startSection('js-css'); ?>
<style type="text/css">
	.notification{
	    text-align: center;
	    background-color: red;
	    color: #fff;
	    font-weight: bold;
	    padding: 20px 10px;
	    font-size: 16px;
	    margin-top: 50px;
	    margin-bottom: 15px
	}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<?php if(Auth::user()->role == 2 || 
	Auth::user()->role == 3 ||
	Auth::user()->role == 5 ||
	Auth::user()->role == 6
): ?>
	<div class="container text-center" style="margin-bottom: 100px">
	    <div class='page_banner_img_common'>
            <img src='/frontend/images/pages-banner.png' class='img-fluid'>
            <div class='overlay__'>
                <p>Plab One</p>
            </div>
        </div>
        
		<h4 class="notification"><?php echo e('SORRY! You Need to Upgrade Your Plan to Advance/Professional to Access'); ?></h4>
		<a href="<?php echo e(route('root_page')); ?>#most_popular_courses" class="btn">Upgrade Now</a>
	</div>

<?php else: ?>



<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/plabone.preparemedicine.com/resources/views/frontend/plab-1.blade.php ENDPATH**/ ?>