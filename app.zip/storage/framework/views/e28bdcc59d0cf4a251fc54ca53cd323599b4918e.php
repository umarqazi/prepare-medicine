<?php $__env->startSection('content'); ?>
<br><br>


    <div class="container">

        <div class="col-sm-12 text-center text-left">
            <h2 class="text-left">
                Lorem Ipsum is simply dummy
            </h2>
            <br>
            <p class="text-left">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </p>
        </div>
        <br><br>
        <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-3 mb-2">
                    
                    <?php if($key%4 == '0'): ?>
                        <a href="<?php echo e(url('q-bank/recall-exam/'.$item->id)); ?>" class="btn btn-spinner col-12" style="border-radius:10px;background:darkviolet"><?php echo e($item->name); ?></a>
                    <?php elseif($key%3 == '0'): ?>
                        <a href="<?php echo e(url('q-bank/recall-exam/'.$item->id)); ?>" class="btn btn-spinner col-12" style="border-radius:10px;background:violet"><?php echo e($item->name); ?></a>
                    <?php elseif($key%2 == '0'): ?>
                        <a href="<?php echo e(url('q-bank/recall-exam/'.$item->id)); ?>" class="btn btn-spinner col-12" style="border-radius:10px;background:darkblue"><?php echo e($item->name); ?></a>
                    <?php else: ?>
                        <a href="<?php echo e(url('q-bank/recall-exam/'.$item->id)); ?>" class="btn btn-spinner col-12" style="border-radius:10px;background:hotpink"><?php echo e($item->name); ?></a>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>



<br><br><br><br>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\question_bank\resources\views/frontend/recall-exam.blade.php ENDPATH**/ ?>