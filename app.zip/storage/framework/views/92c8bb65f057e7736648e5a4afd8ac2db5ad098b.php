<?php $__env->startSection('js-css'); ?>

    <style>
        .user-name{
            color:red;
            display: ruby;
        }
        .user-feedback{
            margin-left: 25px;
        }
        .edit-btn{
            color: green;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
    <br><br>
    <div class="container">
        <h3 class="text-center m-5 text-danger">This page Under Construction</h3>
    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\question_bank\resources\views/frontend/underconstruction.blade.php ENDPATH**/ ?>