<?php if(session()->has('success')): ?>
<div class="alert alert-success">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <?php echo e(session()->get('success')); ?>

</div>
<?php endif; ?>


<?php if(session()->has('error')): ?>
<div class="alert alert-danger text-center">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    <?php echo e(session()->get('error')); ?>

</div>
<?php endif; ?>


<?php if($errors->any()): ?>
<div class="alert alert-danger text-center">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <p> <?php echo e($error); ?> </p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php endif; ?>
<?php /**PATH /home/kohin837/plabone.preparemedicine.com/resources/views/msg/msg.blade.php ENDPATH**/ ?>