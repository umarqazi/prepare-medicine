<?php $__env->startSection('js-css'); ?>

    <style>
        .user-name{
            color:red;
            display: ruby;
        }
        .user-feedback{
            margin-left: 25px;
        }
        .edit-btn{
            color: green;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
    <br><br>
    <div class="container">
        <div class="row">
            <div class="well">
                <h2 class="text-center">Feedback</h2>
                <br>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="list-group">
                        <div class="col-md-12">
                            <h4 class="list-group-item-heading  user-name">
                                <?php echo e($item->user_name); ?>

                                <?php if(isset(Auth::user()->role)): ?>
                                    <?php if($item->user_id == Auth::user()->id): ?>
                                        <a href="<?php echo e(url('our-team/feedback/edit/'.$item->id )); ?>"><i class="fa fa-edit edit-btn"></i></a>
                                        <a href="<?php echo e(url('feedback/drop/'.$item->user_id.'/'.$item->id)); ?>"><i class="fa fa-remove"></i></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </h4>
                            <p class="list-group-item-text user-feedback"> <?php echo e($item->feedback); ?> </p>
                        </div>
                    </div>
                    <br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <br>
        <span>
            <?php echo e($data->links()); ?>

        </span>

        <?php if(isset(Auth::user()->role)): ?>
            <?php if(Auth::user()->role >= 2): ?>
                <br><br><br><br><br>
                <form action="<?php echo e(url('feedback/insert')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
                    <input type="hidden" name="name" value="<?php echo e(Auth::user()->name); ?>">
                    <div class="row">
                            <div class="form-control col-12">
                                <label for="exampleFormControlTextarea6"> Write your opinion about Us </label>
                                <textarea class="form-control z-depth-1" id="exampleFormControlTextarea6" rows="3" placeholder="Write something here..." name="feedback"></textarea>
                            </div>
                    </div>
                    <br>
                    <input type="submit" value="Place a Feedback" class="form-control btn btn-info col-12" style="background:green"">
                </form>
            <?php endif; ?>
        <?php endif; ?>

    </div>
    <br><br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\project\question_bank\resources\views/frontend/feedback.blade.php ENDPATH**/ ?>