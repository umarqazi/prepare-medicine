<?php $__env->startSection('js-css'); ?>

    <style>
        .user-name{
            color:red;
            display: ruby;
        }
        .user-feedback{
            margin-left: 25px;
        }
        .edit-btn{
            color: green;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    
    <br>
    <div class="container">
        <!--<div class='page_banner_img_common'>-->
        <!--    <img src='/frontend/images/pages-banner.png' class='img-fluid'>-->
        <!--    <div class='overlay__'>-->
        <!--        <p>Under Constuction</p>-->
        <!--    </div>-->
        <!--</div>-->
        
        <div class='text-center'>
            <img src='/frontend/images/unserconstruction.png' class='img-fluid'>
        </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/plabone.preparemedicine.com/resources/views/frontend/underconstruction.blade.php ENDPATH**/ ?>