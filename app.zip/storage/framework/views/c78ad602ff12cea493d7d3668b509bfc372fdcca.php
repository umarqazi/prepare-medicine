<?php $__env->startSection('content'); ?>



    <div class="container-fluid" style="padding-left: 30px; padding-right: 30px">
        <div class='page_banner_img_common'>
            <img src='/frontend/images/pages-banner.png' class='img-fluid'>
            <div class='overlay__'>
                <p>Specialities</p>
            </div>
        </div>
        

        <div class="col-lg-12 col-md-12 col-sm-12 text-center text-left">
            <h2 class="text-center" style="font-size: 35px;text-align: center;">
                Specialities
            </h2>
        
            <p class="text-justify">
                Our revision bank is something that we hope will help you through not only the PLAB exam process, but also through other studies you will undertake and with your CPD. The revision notes are bite-size pieces of information that are taken from sources we have researched such as NICE Guidance, SIGN guidance and a whole range of reference materials including research and Cochrane reviews. It is divided into the same categories as the question bank and each note has a ‘flash card’ and a more detailed content.
                We recommend you review the revision notes before entering the question bank, and then afterwards to look at some of the details around the questions or any areas of uncertainty you may have. Remember the words of Helen Keller: We can do anything we want to do if we stick to it long enough. Revision helps us do that.
 
            </p>
        </div>
        <br>
        
         <div class="row" style="padding-left: 45px; padding-right: 45px">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4 col-sm-6 mb-2">
                    <a href="<?php echo e(url('q-bank/revision-category/question/'.$item->id)); ?>" class="btn btn-spinner col-12 p-0" style="background:<?php echo e($item->cat_color); ?>;padding:0;border-radius:10px;overflow:hidden">
                        <img src="<?php echo e(url('storage/photos/'.$item->cat_img)); ?>" alt="" style="width:35%;float:left;height:55px;">
                        <span style="margin-top:17px"><?php echo e($item->name); ?></span>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo $data->render(); ?>


  </div>


<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master-frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kohin837/preparemedicine.com/resources/views/frontend/revision-category.blade.php ENDPATH**/ ?>